/**
 * Swiss Extensions — Service Worker (MV3).
 * Tab Hibernate + Page Capture + Site Blocker.
 */

importScripts('core_logic.js');

const ALARM_CHECK_NAME = 'tabHibernateCheck';
const ALARM_CHECK_PERIOD_MINUTES = 1;
const INACTIVITY_MINUTES = 5;
const MAX_INACTIVITY_MINUTES = 24 * 60;
const CHECK_PERIOD_OPTIONS = [1, 2, 5];
const FAVICON_REFRESH_BATCH_MAX = 50;
const FAVICON_REFRESH_TIMEOUT_MS = 6000;
const FAVICON_REFRESH_ALARM = 'tabHibernateFaviconRefresh';
const FAVICON_REFRESH_JOB_KEY = 'faviconRefreshJob';
const FAVICON_REFRESH_PROGRESS_KEY = 'faviconRefreshProgress';
/** Keep backup-by-date keys only for the last N days; remove older ones. */
const BACKUP_RETENTION_DAYS = 30;
const BACKUP_KEY_CATALOG = 'backupKeyCatalog';
const DAILY_SESSION_SNAPSHOT_PREFIX = 'dailySessionSnapshot_';
const DAILY_SESSION_SNAPSHOT_CATALOG = 'dailySessionSnapshotCatalog';
const DAILY_SESSION_SNAPSHOT_MAX_ENTRIES = 5000;
const LIGHT_MAINTENANCE_INTERVAL_MS = 15 * 60 * 1000;
const LAST_LIGHT_MAINTENANCE_AT = 'lastLightMaintenanceAt';
const PLACEHOLDER_MAINTENANCE_INTERVAL_MS = 6 * 60 * 60 * 1000;
const LAST_PLACEHOLDER_MAINTENANCE_AT = 'lastPlaceholderMaintenanceAt';
const PLACEHOLDER_MAINTENANCE_CURSOR = 'placeholderMaintenanceCursor';
const PLACEHOLDER_REBIND_BATCH_MAX = 100;
const ORPHAN_ARCHIVE_BATCH_MAX = 100;
const RUNTIME_PLACEHOLDER_REPAIR_KEY = 'runtimePlaceholderRepairMarker';
const PLACEHOLDER_REPAIR_BATCH_SIZE = 20;
/** Site Blocker schedule alarm (Chrome may drop alarms after browser update). */
const SITE_BLOCKER_SCHEDULE_ALARM = 'swissSiteBlockerSchedule';
const SITE_BLOCKER_SCHEDULE_PERIOD_MINUTES = 2;
/** Periodically persist URLs of tabs on blocked domains (survives disable/uninstall). */
const BLOCKER_PRESERVE_ALARM = 'swissBlockerPreserveTabs';
const BLOCKER_PRESERVE_PERIOD_MINUTES = 2;
const BLOCKER_TAB_URL_KEY = 'blockerTabUrlByTabId';
const SITE_BLOCKER_RULE_SIGNATURE_KEY = 'siteBlockerRuleSignature';
const BLOCKER_OPEN_TAB_ENFORCE_AT_KEY = 'lastBlockerOpenTabEnforceAt';
const CAPTURE_STATE_KEY = 'pageCaptureState';
const CAPTURE_STATE_STALE_MS = 3 * 60 * 1000;
const REMOVED_TAB_CLEANUP_DELAY_MS = 150;
const BADGE_UPDATE_DELAY_MS = 200;
/** Serialize Site Blocker applyRules; parallel calls after SW wake broke DNR on recent Chrome. */
let siteBlockerApplyChain = Promise.resolve();
let blockerTabUrlMutationChain = Promise.resolve();
let suspendedUrlIndexMutationChain = Promise.resolve();
const pendingRemovedTabIds = new Set();
const pendingRemovedTabDataIds = new Set();
let removedTabCleanupTimer = null;
let badgeUpdateTimer = null;

// Last activity per tabId (in memory + synced on messages). After SW sleep, memory is empty — restore from storage at start of onAlarmCheck.
let lastActivityByTab = new Map();
let lastPersistTime = 0;
const PERSIST_THROTTLE_MS = 4000;
/** One-time lightweight SW init per lifecycle — do not reset timers on every wake. */
let swReadyPromise = null;
const lastActiveTabByWindow = new Map();
let lastFocusedWindowId = null;
let alarmCheckPromise = null;
let placeholderMaintenanceScheduled = false;
let siteBlockerNavEnforceChain = Promise.resolve();
let captureInProgress = false;
let runtimePlaceholderRepairPromise = null;
let dailySessionSnapshotPromise = null;
/** Ignore Chrome's transient groupId=-1 while a tab navigates to suspended.html. */
const placeholderGroupTransitionUntil = new Map();
/** Last http(s) navigation URL per tab before chrome-error (Site Blocker). */
const lastHttpUrlByTabId = new Map();
/** Prevent onUpdated and webNavigation from converting the same blocked tab twice. */
const blockerPlaceholderConversions = new Set();
const BLOCKER_OPEN_TAB_ENFORCE_MS = 5 * 60 * 1000;

async function getStoredState() {
  const raw = await chrome.storage.local.get(['lastActivityByTab', 'settings', 'suspendedToday', 'suspendedTodayDate']);
  if (raw.lastActivityByTab && typeof raw.lastActivityByTab === 'object') {
    const now = Date.now();
    for (const [k, v] of Object.entries(raw.lastActivityByTab)) {
      const id = Number(k);
      if (Number.isNaN(id)) continue;
      const ts = typeof v === 'number' && !Number.isNaN(v) && v > 0 ? v : now;
      const prev = lastActivityByTab.get(id);
      lastActivityByTab.set(id, prev == null ? ts : Math.max(prev, ts));
    }
  }
  return raw;
}

/** Tabs with no activity record get a grace period; seeded only in onAlarmCheck, not on every SW wake. */
function seedActivityForUnknownTabs(tabs) {
  const now = Date.now();
  let needPersist = false;
  for (const tab of tabs) {
    if (!tab.id || lastActivityByTab.has(tab.id)) continue;
    const u = tab.url || '';
    if (u.startsWith('chrome://') || u.startsWith('chrome-extension://')) continue;
    lastActivityByTab.set(tab.id, now);
    needPersist = true;
  }
  return needPersist;
}

async function persistLastActivity(force = false) {
  const now = Date.now();
  if (!force && now - lastPersistTime < PERSIST_THROTTLE_MS) return;
  lastPersistTime = now;
  try {
    const obj = Object.fromEntries(
      [...lastActivityByTab.entries()].map(([k, v]) => [String(k), v])
    );
    await chrome.storage.local.set({ lastActivityByTab: obj });
  } catch (e) {
    console.warn('[TabHibernate] persistLastActivity failed', e);
  }
}

/** Check by full URL of current extension (for our own redirects). */
function isSuspendedPlaceholderUrl(url) {
  const base = chrome.runtime.getURL('ui-dist/suspended.html');
  return url && url.startsWith(base.split('?')[0]);
}

/** Detect placeholder by path and tabId; works after extension update when tabs still have old chrome-extension://OLD_ID/suspended.html. */
function isPlaceholderTabUrl(url) {
  if (!url) return false;
  try {
    const u = new URL(url);
    return u.protocol === 'chrome-extension:'
      && u.pathname.endsWith('suspended.html')
      && u.searchParams.has('tabId');
  } catch (e) {
    return false;
  }
}

/** Map capture errors to user-facing messages (aligned with PdfExtensions). */
function formatSwissCaptureError(e) {
  const m = (e && e.message) || String(e);
  const lower = m.toLowerCase();
  if (lower.includes('no active tab')) return 'No active tab.';
  if (lower.includes('cannot access') || lower.includes('chrome://')) {
    return 'This page cannot be captured (system page or restricted by Chrome).';
  }
  if (lower.includes('chrome-extension://')) return 'Extension pages cannot be captured.';
  if (lower.includes('could not establish connection') || lower.includes('receiving end does not exist')) {
    return 'Could not connect to the page. Reload the tab and try again.';
  }
  if (lower.includes('capturevisible') || lower.includes('cannot capture')) {
    return 'Tab screenshot unavailable (page or window is in an invalid state).';
  }
  return m.length > 160 ? `${m.slice(0, 157)}…` : m;
}

/** True if tab belongs to a Chrome Tab Group (groupId !== -1). */
function isTabInGroup(tab) {
  return tab && tab.groupId != null && tab.groupId !== -1;
}

/** Stable saved group key: window + chrome groupId; batch-save adds batchId. */
function createSavedGroupKey(chromeGroupId, { windowId, saveBatchId } = {}) {
  const gid = chromeGroupId ?? -1;
  const wid = windowId ?? 0;
  if (saveBatchId != null) return `gk_${saveBatchId}_w${wid}_g${gid}`;
  return `gk_${Date.now()}_w${wid}_g${gid}`;
}

const CHROME_GROUP_KEY_REGISTRY = 'chromeGroupKeyRegistry';

/** Stable key for a live Chrome group (avoids merging distinct groups that share a title). */
async function resolveGroupKeyForChromeGroup(groupId, groupInfo, windowId, saveBatchId = null) {
  if (saveBatchId != null) {
    return createSavedGroupKey(groupId, { windowId, saveBatchId });
  }
  const regKey = `${windowId ?? 0}:${groupId}`;
  const { [CHROME_GROUP_KEY_REGISTRY]: registry = {} } = await chrome.storage.local.get(CHROME_GROUP_KEY_REGISTRY);
  if (registry[regKey]) return registry[regKey];
  const groupKey = createSavedGroupKey(groupId, { windowId });
  registry[regKey] = groupKey;
  await chrome.storage.local.set({ [CHROME_GROUP_KEY_REGISTRY]: registry });
  return groupKey;
}

/** Normalize legacy group keys to gk_<id>_w<wid>_g<gid>. */
function normalizeGroupKey(raw) {
  if (!raw || typeof raw !== 'string') return '';
  if (/^gk_\d+_w\d+_g-?\d+$/.test(raw)) return raw;
  let m = /^gk_(\d+)_(-?\d+)$/.exec(raw);
  if (m) return `gk_${m[1]}_w0_g${m[2]}`;
  m = /^gk_(-?\d+)$/.exec(raw);
  if (m) return `gk_0_w0_g${m[1]}`;
  return raw;
}

function clearSavedGroupFields(item) {
  const cleared = { ...item };
  delete cleared.groupKey;
  delete cleared.groupTitle;
  delete cleared.groupColor;
  delete cleared.groupCollapsed;
  delete cleared.tabIndexInGroup;
  delete cleared.groupId;
  delete cleared.windowId;
  return cleared;
}

/** Drop registry entries for Chrome tab groups that no longer exist. */
async function pruneChromeGroupKeyRegistry() {
  try {
    const tabs = await chrome.tabs.query({});
    const live = new Set();
    for (const tab of tabs) {
      if (isTabInGroup(tab)) live.add(`${tab.windowId}:${tab.groupId}`);
    }
    const { [CHROME_GROUP_KEY_REGISTRY]: registry = {} } = await chrome.storage.local.get(CHROME_GROUP_KEY_REGISTRY);
    let changed = false;
    for (const k of Object.keys(registry)) {
      if (!live.has(k)) {
        delete registry[k];
        changed = true;
      }
    }
    if (changed) await chrome.storage.local.set({ [CHROME_GROUP_KEY_REGISTRY]: registry });
  } catch (e) {
    console.warn('[TabHibernate] pruneChromeGroupKeyRegistry failed', e);
  }
}

/** Group metadata fields persisted to storage and used on restore. */
function pickSavedGroupFields(entry) {
  if (!entry?.groupKey) return {};
  return {
    groupKey: entry.groupKey,
    groupTitle: entry.groupTitle || '',
    groupColor: entry.groupColor || 'grey',
    groupCollapsed: entry.groupCollapsed === true,
    tabIndexInGroup: typeof entry.tabIndexInGroup === 'number' ? entry.tabIndexInGroup : 0,
  };
}

function copyGroupMetaToEntry(entry, tabMeta) {
  if (!tabMeta) return entry;
  return { ...entry, ...pickSavedGroupFields(tabMeta) };
}

/** Build tabId → group metadata map; saveBatchId ties one save/close operation. */
async function buildGroupMetaMapForTabs(tabs, saveBatchId = null) {
  const meta = new Map();
  const byGroup = new Map();
  for (const tab of tabs) {
    if (!isTabInGroup(tab)) continue;
    if (!byGroup.has(tab.groupId)) byGroup.set(tab.groupId, []);
    byGroup.get(tab.groupId).push(tab);
  }
  for (const [groupId, groupTabs] of byGroup) {
    groupTabs.sort((a, b) => a.index - b.index);
    let groupInfo = { title: '', color: 'grey', collapsed: false };
    try {
      groupInfo = await chrome.tabGroups.get(groupId);
    } catch (_) {}
    const groupKey = await resolveGroupKeyForChromeGroup(
      groupId,
      groupInfo,
      groupTabs[0]?.windowId,
      saveBatchId,
    );
    groupTabs.forEach((tab, idx) => {
      meta.set(tab.id, {
        groupKey,
        groupTitle: groupInfo.title || '',
        groupColor: groupInfo.color || 'grey',
        groupCollapsed: groupInfo.collapsed === true,
        tabIndexInGroup: idx,
      });
    });
  }
  return meta;
}

/** Open one hibernate placeholder tab; returns the created tab. */
function waitForTabComplete(tabId, timeoutMs = 8000) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      resolve();
    };
    const onUpdated = (updatedTabId, changeInfo) => {
      if (updatedTabId === tabId && changeInfo.status === 'complete') finish();
    };
    const timer = setTimeout(finish, timeoutMs);
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab.status === 'complete') finish();
    }).catch(finish);
  });
}

async function discardInactivePlaceholder(tab) {
  if (!tab?.id || tab.discarded) return false;
  // Active means visible inside its own window. The window does not need to
  // have OS focus to remain on screen, so killing this renderer causes a flash.
  if (tab.active) return false;
  // Keep the renderer alive until Chrome has actually observed the page's
  // favicon. A fixed delay races on busy sessions and leaves the extension
  // action icon on every discarded placeholder.
  const faviconReady = await waitForPlaceholderFavicon(tab.id);
  // If the renderer is unloaded before the canvas-backed favicon is ready,
  // Chrome falls back to the extension icon for every suspended tab. Leave the
  // page alive on timeout; a later maintenance/update pass can retry safely.
  if (!faviconReady) return false;
  const fresh = await chrome.tabs.get(tab.id).catch(() => null);
  if (!fresh || fresh.active || (!isPlaceholderTabUrl(fresh.url) && !isSuspendedPlaceholderUrl(fresh.url))) {
    return false;
  }
  try {
    await chrome.tabs.discard(fresh.id);
    return true;
  } catch (_) {
    return false;
  }
}

function isResolvedPlaceholderFavicon(favIconUrl) {
  const url = String(favIconUrl || '');
  // Only a self-contained canvas result is safe to keep after discard.
  // Treating the temporary SVG as ready unloads the page before the site's
  // monochrome favicon is written, after which Chrome shows the red extension
  // icon for every suspended tab.
  return url.startsWith('data:image/');
}

function waitForPlaceholderFavicon(tabId, timeoutMs = 8000) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (ready = false) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      resolve(ready);
    };
    const onUpdated = (updatedTabId, changeInfo, updatedTab) => {
      if (updatedTabId !== tabId) return;
      if (isResolvedPlaceholderFavicon(changeInfo.favIconUrl || updatedTab?.favIconUrl)) finish(true);
    };
    const timer = setTimeout(() => finish(false), timeoutMs);
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId).then((current) => {
      if (isResolvedPlaceholderFavicon(current?.favIconUrl)) finish(true);
    }).catch(() => finish(false));
  });
}

/**
 * Schedule one durable favicon refresh step. The alarm survives service-worker
 * shutdowns, unlike a long runtime message or an in-memory timer.
 */
async function scheduleSuspendedFaviconRefresh(delayMs = 100) {
  await chrome.alarms.create(FAVICON_REFRESH_ALARM, {
    when: Date.now() + Math.max(0, delayMs),
  });
}

async function startSuspendedFaviconRefresh() {
  const stored = await chrome.storage.local.get(FAVICON_REFRESH_JOB_KEY);
  const current = stored[FAVICON_REFRESH_JOB_KEY];
  if (current?.status === 'running' && Array.isArray(current.tabIds)) {
    await scheduleSuspendedFaviconRefresh();
    return {
      started: true,
      running: true,
      alreadyRunning: true,
      done: Number(current.index) || 0,
      total: current.tabIds.length,
    };
  }

  const tabs = await chrome.tabs.query({});
  const placeholders = tabs.filter((tab) => (
    tab?.id && (isPlaceholderTabUrl(tab.url) || isSuspendedPlaceholderUrl(tab.url))
  ));
  const unresolved = placeholders.filter((tab) => !isResolvedPlaceholderFavicon(tab.favIconUrl));
  const candidates = unresolved.filter((tab) => !tab.active);
  const skippedActive = unresolved.length - candidates.length;
  const batch = candidates.slice(0, FAVICON_REFRESH_BATCH_MAX);
  const job = {
    status: 'running',
    tabIds: batch.map((tab) => tab.id),
    index: 0,
    refreshed: 0,
    failed: 0,
    remaining: Math.max(0, candidates.length - batch.length),
    skippedActive,
    startedAt: Date.now(),
  };
  const progress = {
    status: batch.length ? 'running' : 'complete',
    done: 0,
    total: batch.length,
    refreshed: 0,
    failed: 0,
    remaining: job.remaining,
    skippedActive,
  };

  if (!batch.length) {
    await chrome.storage.local.remove(FAVICON_REFRESH_JOB_KEY);
    await chrome.storage.local.set({ [FAVICON_REFRESH_PROGRESS_KEY]: progress });
    return { started: false, ...progress };
  }

  await chrome.storage.local.set({
    [FAVICON_REFRESH_JOB_KEY]: job,
    [FAVICON_REFRESH_PROGRESS_KEY]: progress,
  });
  await scheduleSuspendedFaviconRefresh();
  return { started: true, running: true, done: 0, total: batch.length };
}

/** Load one suspended placeholder, resolve its favicon, then put it to sleep. */
async function processNextSuspendedFaviconRefresh() {
  const stored = await chrome.storage.local.get(FAVICON_REFRESH_JOB_KEY);
  const job = stored[FAVICON_REFRESH_JOB_KEY];
  if (job?.status !== 'running' || !Array.isArray(job.tabIds)) return;

  const index = Number(job.index) || 0;
  if (index >= job.tabIds.length) {
    await chrome.storage.local.remove(FAVICON_REFRESH_JOB_KEY);
    return;
  }

  // Leave a watchdog alarm behind before doing renderer work. If Chrome stops
  // the worker mid-step, the same persisted cursor is retried on the next wake.
  await scheduleSuspendedFaviconRefresh(FAVICON_REFRESH_TIMEOUT_MS + 5000);
  const tabId = job.tabIds[index];
  let refreshed = Number(job.refreshed) || 0;
  let failed = Number(job.failed) || 0;
  let skippedActive = Number(job.skippedActive) || 0;

  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.active) {
      skippedActive += 1;
    } else if (!isPlaceholderTabUrl(tab.url) && !isSuspendedPlaceholderUrl(tab.url)) {
      failed += 1;
    } else if (isResolvedPlaceholderFavicon(tab.favIconUrl)) {
      refreshed += 1;
    } else {
      const faviconReady = waitForPlaceholderFavicon(tabId, FAVICON_REFRESH_TIMEOUT_MS);
      await chrome.tabs.reload(tabId);
      if (await faviconReady) refreshed += 1;
      else failed += 1;
    }
  } catch (e) {
    failed += 1;
    console.warn('[TabHibernate] favicon refresh failed', tabId, e);
  } finally {
    try {
      const fresh = await chrome.tabs.get(tabId);
      if (!fresh.active && !fresh.discarded
        && (isPlaceholderTabUrl(fresh.url) || isSuspendedPlaceholderUrl(fresh.url))) {
        await chrome.tabs.discard(fresh.id);
      }
    } catch (_) {}
  }

  const nextIndex = index + 1;
  const complete = nextIndex >= job.tabIds.length;
  const progress = {
    status: complete ? 'complete' : 'running',
    done: nextIndex,
    total: job.tabIds.length,
    refreshed,
    failed,
    remaining: Number(job.remaining) || 0,
    skippedActive,
  };

  if (complete) {
    await chrome.storage.local.set({ [FAVICON_REFRESH_PROGRESS_KEY]: progress });
    await chrome.storage.local.remove(FAVICON_REFRESH_JOB_KEY);
    await chrome.alarms.clear(FAVICON_REFRESH_ALARM);
    return;
  }

  await chrome.storage.local.set({
    [FAVICON_REFRESH_JOB_KEY]: {
      ...job,
      index: nextIndex,
      refreshed,
      failed,
      skippedActive,
    },
    [FAVICON_REFRESH_PROGRESS_KEY]: progress,
  });
  await scheduleSuspendedFaviconRefresh();
}

async function openPlaceholderTabForItem(item, windowId = null) {
  const { url, title } = item;
  const createProperties = { url: 'about:blank', active: false };
  if (Number.isInteger(windowId)) createProperties.windowId = windowId;
  const tab = await chrome.tabs.create(createProperties);
  const payload = {
    url,
    title: title || '',
    favIconUrl: '',
    tabId: tab.id,
    ...pickSavedGroupFields(item),
  };
  if (payload.groupKey) payload.groupKey = normalizeGroupKey(payload.groupKey);
  await persistSuspendedPayload(`suspended_${tab.id}`, payload);
  const suspendedUrl = buildSuspendedPlaceholderUrl(tab.id, { url, title });
  await chrome.tabs.update(tab.id, { url: suspendedUrl });
  // History can contain hundreds of entries. Finish loading only a small
  // batch at a time, then unload the inactive placeholder. It reloads normally
  // when the user activates it, without leaving a permanent spinner or using RAM.
  await waitForTabComplete(tab.id);
  await discardInactivePlaceholder(tab).catch(() => false);
  return tab;
}

/** Re-group tabs by saved groupKey. forceRegroup=true only for History/open restore; maintenance must not override user edits. */
async function applySavedTabGroups(pairs, { forceRegroup = false } = {}) {
  const byKey = new Map();
  for (const { tabId, item } of pairs) {
    const key = normalizeGroupKey(item?.groupKey);
    if (!key) continue;
    if (!byKey.has(key)) byKey.set(key, { meta: item, tabIds: [] });
    byKey.get(key).tabIds.push({ tabId, order: item.tabIndexInGroup ?? 0 });
  }
  for (const { meta, tabIds } of byKey.values()) {
    tabIds.sort((a, b) => a.order - b.order);
    const ids = [...new Set(tabIds.map((t) => t.tabId))];
    if (!ids.length) continue;

    const tabInfos = (await Promise.all(ids.map((id) => chrome.tabs.get(id).catch(() => null)))).filter(Boolean);
    if (!tabInfos.length) continue;

    const update = {};
    if (meta.groupTitle) update.title = meta.groupTitle;
    if (meta.groupColor) update.color = meta.groupColor;
    if (typeof meta.groupCollapsed === 'boolean') update.collapsed = meta.groupCollapsed;

    const groupedIds = tabInfos
      .map((t) => t.groupId)
      .filter((g) => g != null && g !== -1);
    const uniqueGroupIds = new Set(groupedIds);

    if (uniqueGroupIds.size === 1 && tabInfos.every((t) => t.groupId === groupedIds[0])) {
      if (forceRegroup && Object.keys(update).length) {
        try {
          await chrome.tabGroups.update(groupedIds[0], update);
        } catch (_) {}
      }
      continue;
    }

    if (!forceRegroup) continue;

    try {
      const groupId = await chrome.tabs.group({ tabIds: tabInfos.map((t) => t.id) });
      if (Object.keys(update).length) await chrome.tabGroups.update(groupId, update);
    } catch (e) {
      console.warn('[TabHibernate] applySavedTabGroups failed', e);
    }
  }
}

/**
 * Tab cannot be suspended: active (unless allowActive), pinned (when suspendPinnedTabs is off), grouped when skipGroupedInHibernate, audible, system, incognito, or placeholder.
 * allowActive: when true, allows suspending the active tab (e.g. "Suspend current" button).
 * Pass `settings` from callers that already called getSettings() to avoid repeated storage reads.
 * Note: Both Discard and Placeholder unload the page; unsaved forms and SPA state may be lost (Chrome API limitation).
 */
async function isTabEligibleForSuspend(tab, { allowActive = false, settings: settingsPreloaded } = {}) {
  if (!tab || !tab.id) return false;
  if (tab.discarded) return false;
  const settings = settingsPreloaded || await getSettings();
  if (tab.active && !allowActive) return false;
  if (tab.pinned && !settings.suspendPinnedTabs) return false;
  if (settings.skipGroupedInHibernate && isTabInGroup(tab)) return false;
  if (tab.audible) return false;
  if (tab.incognito) return false;
  const u = (tab.url || '').toLowerCase();
  if (u.startsWith('chrome://') || u.startsWith('chrome-extension://')) return false;
  if (isSuspendedPlaceholderUrl(tab.url) || isPlaceholderTabUrl(tab.url)) return false; // already a placeholder
  return true;
}

/** Get settings from storage (defaults not overwritten by undefined from storage). */
async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  const s = settings || {};
  const parsedTimeout = SwissCore.normalizeInactivityMinutes(
    s.timeoutMinutes,
    INACTIVITY_MINUTES,
    MAX_INACTIVITY_MINUTES,
  );
  const parsedPeriod = CHECK_PERIOD_OPTIONS.includes(Number(s.checkPeriodMinutes))
    ? Number(s.checkPeriodMinutes)
    : ALARM_CHECK_PERIOD_MINUTES;
  const excludedDomains = parseDomainList(s.excludedDomains);
  const smartPlaceholderDomains = parseDomainList(s.smartPlaceholderDomains);
  const smartDiscardDomains = parseDomainList(s.smartDiscardDomains);
  return {
    enabled: s.enabled !== false,
    timeoutMinutes: parsedTimeout,
    checkPeriodMinutes: parsedPeriod,
    excludedDomains,
    smartRulesEnabled: s.smartRulesEnabled === true,
    smartDefaultMode: s.smartDefaultMode === 'placeholder' ? 'placeholder' : 'discard',
    smartUseHeuristicsFallback: s.smartUseHeuristicsFallback !== undefined
      ? s.smartUseHeuristicsFallback !== false
      : s.smartHeuristicsFallback !== false,
    smartPlaceholderDomains,
    smartDiscardDomains,
    /** Default placeholder so new installs get suspended.html, not silent chrome.discard (UI also defaults to Placeholder). */
    mode: ['placeholder', 'smart', 'discard'].includes(s.mode) ? s.mode : 'placeholder',
    /** When true (default), pinned tabs participate in hibernate / Suspend all / Close & save. */
    suspendPinnedTabs: s.suspendPinnedTabs !== false,
    /** When true, tabs in Chrome tab groups are never suspended automatically or via bulk actions. */
    skipGroupedInHibernate: s.skipGroupedInHibernate === true,
  };
}

function normalizeDomain(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/\/.*$/, '');
}

function parseDomainList(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  const seen = new Set();
  for (const value of list) {
    const domain = normalizeDomain(value);
    if (!domain || seen.has(domain)) continue;
    seen.add(domain);
    out.push(domain);
  }
  return out;
}

function getTabHost(tab) {
  try {
    return new URL(String(tab?.url || '')).hostname.toLowerCase();
  } catch (e) {
    return '';
  }
}

/** Grouping context: one storage read instead of N per tab. */
async function buildDomainGroupingContext(tabs) {
  const blockerData = await chrome.storage.local.get(BLOCKER_TAB_URL_KEY);
  const blockerMap = { ...(blockerData[BLOCKER_TAB_URL_KEY] || {}) };
  const suspendKeys = new Set();
  for (const tab of tabs) {
    if (!tab?.id || !tab.url) continue;
    if (!isPlaceholderTabUrl(tab.url) && !isSuspendedPlaceholderUrl(tab.url)) continue;
    suspendKeys.add(`suspended_${tab.id}`);
    try {
      const tid = new URL(tab.url).searchParams.get('tabId');
      if (tid) suspendKeys.add(`suspended_${tid}`);
    } catch (_) {}
  }
  const suspendedData = suspendKeys.size
    ? await chrome.storage.local.get([...suspendKeys])
    : {};
  return { blockerMap, suspendedData };
}

function getPlaceholderRestoreUrlFromContext(tab, ctx) {
  if (!tab?.url) return null;
  if (!isPlaceholderTabUrl(tab.url) && !isSuspendedPlaceholderUrl(tab.url)) return null;
  try {
    if (tab.id) {
      const item = ctx.suspendedData[`suspended_${tab.id}`];
      if (item?.url) return item.url;
    }
    const u = new URL(tab.url);
    const tid = u.searchParams.get('tabId');
    if (tid) {
      const item = ctx.suspendedData[`suspended_${tid}`];
      if (item?.url) return item.url;
    }
    const fallback = u.searchParams.get('u');
    if (fallback && (fallback.startsWith('http') || fallback.startsWith('file'))) return fallback;
  } catch (_) {}
  return null;
}

function resolveBlockerTabPageUrlFromContext(tab, ctx) {
  if (!tab?.id) return '';
  let url = tab.pendingUrl || tab.url || '';
  if (isPlaceholderTabUrl(url) || isSuspendedPlaceholderUrl(url)) {
    url = getPlaceholderRestoreUrlFromContext(tab, ctx) || url;
  }
  if (hasRestorableUrl(url) && !isChromeBlockedPageUrl(url)) return url;
  const entry = ctx.blockerMap[String(tab.id)];
  if (entry?.url && hasRestorableUrl(entry.url)) return entry.url;
  const lastNav = lastHttpUrlByTabId.get(tab.id);
  if (lastNav && hasRestorableUrl(lastNav) && !isChromeBlockedPageUrl(lastNav)) return lastNav;
  return '';
}

function getTabDomainFromContext(tab, ctx, blockedDomains = []) {
  const url = resolveBlockerTabPageUrlFromContext(tab, ctx);
  if (url && hasRestorableUrl(url)) {
    if (url.startsWith('file://')) return 'local files';
    try {
      return new URL(url).hostname.replace(/^www\./i, '').toLowerCase();
    } catch (_) {
      return '';
    }
  }
  return guessBlockedTabDomain(tab, blockedDomains);
}

/** Resolve chrome-error tab URL when missing: single blocked domain or title match. */
function guessBlockedTabDomain(tab, blockedDomains) {
  if (!tab?.id || !blockedDomains?.length) return '';
  if (!isChromeBlockedPageUrl(tab.url || '')) return '';
  const normalized = blockedDomains.map(sbNormDomain).filter(Boolean);
  if (!normalized.length) return '';
  const title = (tab.title || '').toLowerCase();
  const titleMatches = normalized.filter((d) => title.includes(d) || title.includes(`www.${d}`));
  if (titleMatches.length === 1) return titleMatches[0];
  if (normalized.length === 1) return normalized[0];
  return '';
}

async function convertChromeErrorTabsForGrouping(tabs, ctx) {
  const targets = tabs.filter(
    (t) => t?.id && isChromeBlockedPageUrl(t.url || '') && resolveBlockerTabPageUrlFromContext(t, ctx),
  );
  if (!targets.length) return;
  await Promise.all(targets.map(async (tab) => {
    const pageUrl = resolveBlockerTabPageUrlFromContext(tab, ctx);
    if (!pageUrl) return;
    await suspendPlaceholder(tab.id, pageUrl, tab.title, tab.favIconUrl, {
      windowId: tab.windowId,
      skipFavicon: true,
      skipBookmark: true,
    });
  }));
}

const TAB_GROUP_COLORS = ['grey', 'blue', 'red', 'yellow', 'green', 'pink', 'purple', 'cyan', 'orange'];

function pickTabGroupColor(seed) {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (Math.imul(31, h) + seed.charCodeAt(i)) >>> 0;
  return TAB_GROUP_COLORS[h % TAB_GROUP_COLORS.length];
}

function isTabEligibleForDomainGrouping(tab) {
  if (!tab?.id || isTabInGroup(tab)) return false;
  const lower = (tab.url || '').toLowerCase();
  const isPlaceholder = isPlaceholderTabUrl(tab.url) || isSuspendedPlaceholderUrl(tab.url);
  const isBlockedPage = isChromeBlockedPageUrl(tab.url);
  if (
    !isPlaceholder
    && !isBlockedPage
    && (
      lower.startsWith('chrome://')
      || lower.startsWith('chrome-extension://')
      || lower.startsWith('edge://')
      || lower.startsWith('about:')
      || lower.startsWith('devtools://')
    )
  ) return false;
  return true;
}

/** Legacy SW grouping: one Chrome group per domain per window (UI uses side panel URL grouping). */
async function runGroupTabsByDomain({ allWindows = false, windowId = null } = {}) {
  const queryOpts = allWindows
    ? {}
    : (typeof windowId === 'number' ? { windowId } : { lastFocusedWindow: true });
  let tabs = await chrome.tabs.query(queryOpts);
  const blockedDomains = await getConfiguredBlockerDomains();
  let ctx = await buildDomainGroupingContext(tabs);

  const needBackfill = tabs.filter(
    (t) => t?.id && isChromeBlockedPageUrl(t.url || '') && !resolveBlockerTabPageUrlFromContext(t, ctx),
  );
  if (needBackfill.length) {
    await Promise.all(needBackfill.map(async (tab) => {
      try {
        const fresh = await chrome.tabs.get(tab.id);
        const pending = fresh.pendingUrl || '';
        if (!pending.startsWith('http') || !hasRestorableUrl(pending) || isChromeBlockedPageUrl(pending)) return;
        ctx.blockerMap[String(tab.id)] = { url: pending, title: fresh.title || pending, at: Date.now() };
        lastHttpUrlByTabId.set(tab.id, pending);
        rememberBlockerTabUrl(tab.id, pending, fresh.title).catch(() => {});
      } catch (_) {}
    }));
  }

  await convertChromeErrorTabsForGrouping(tabs, ctx);
  tabs = await chrome.tabs.query(queryOpts);
  ctx = await buildDomainGroupingContext(tabs);

  const byWindowDomain = new Map();
  for (const tab of tabs) {
    if (!isTabEligibleForDomainGrouping(tab)) continue;
    const domain = getTabDomainFromContext(tab, ctx, blockedDomains);
    if (!domain) continue;
    if (!byWindowDomain.has(tab.windowId)) byWindowDomain.set(tab.windowId, new Map());
    const byDomain = byWindowDomain.get(tab.windowId);
    if (!byDomain.has(domain)) byDomain.set(domain, []);
    byDomain.get(domain).push(tab);
  }

  let groupsCreated = 0;
  let tabsGrouped = 0;

  for (const byDomain of byWindowDomain.values()) {
    for (const [domain, domainTabs] of byDomain) {
      if (domainTabs.length < 2) continue;
      domainTabs.sort((a, b) => a.index - b.index);
      const tabIds = domainTabs.map((t) => t.id).filter(Boolean);
      if (tabIds.length < 2) continue;
      try {
        const groupId = await chrome.tabs.group({ tabIds });
        await chrome.tabGroups.update(groupId, {
          title: domain.slice(0, 256),
          color: pickTabGroupColor(domain),
        });
        groupsCreated++;
        tabsGrouped += tabIds.length;
      } catch (e) {
        const unresolved = domainTabs.filter(
          (t) => t?.id && isChromeBlockedPageUrl(t.url || '') && !resolveBlockerTabPageUrlFromContext(t, ctx),
        );
        if (unresolved.length >= 2 && domain) {
          const fallbackUrl = `https://${domain}/`;
          await Promise.all(unresolved.map((tab) => suspendPlaceholder(tab.id, fallbackUrl, tab.title || domain, '', {
            windowId: tab.windowId,
            skipFavicon: true,
            skipBookmark: true,
          })));
          try {
            const groupId = await chrome.tabs.group({ tabIds });
            await chrome.tabGroups.update(groupId, {
              title: domain.slice(0, 256),
              color: pickTabGroupColor(domain),
            });
            groupsCreated++;
            tabsGrouped += tabIds.length;
            continue;
          } catch (retryErr) {
            console.warn('[TabHibernate] groupTabsByDomain retry failed', domain, retryErr);
          }
        }
        console.warn('[TabHibernate] groupTabsByDomain failed', domain, e);
      }
    }
  }

  return {
    groupsCreated,
    tabsGrouped,
    eligible: tabs.filter((t) => t?.id && !isTabInGroup(t)).length,
  };
}

function matchesDomain(host, domains) {
  if (!host || !Array.isArray(domains) || domains.length === 0) return false;
  return domains.some((d) => host === d || host.endsWith(`.${d}`));
}

function isTabExcludedByDomain(tab, excludedDomains) {
  const host = getTabHost(tab);
  return matchesDomain(host, excludedDomains);
}

function getSuspendModeForTab(settings, tab) {
  if (settings.mode !== 'smart') return settings.mode;
  const host = getTabHost(tab);
  if (settings.smartRulesEnabled) {
    if (matchesDomain(host, settings.smartPlaceholderDomains)) return 'placeholder';
    if (matchesDomain(host, settings.smartDiscardDomains)) return 'discard';
    if (!settings.smartUseHeuristicsFallback) return settings.smartDefaultMode;
  }
  const url = String(tab?.url || '');
  const title = String(tab?.title || '').toLowerCase();
  const hasQuery = url.includes('?');
  const webAppHint = /(mail|calendar|docs|drive|notion|figma|slack|telegram|discord|jira|github)/.test(url.toLowerCase())
    || /(dashboard|inbox|workspace|crm|project)/.test(title);
  return hasQuery || webAppHint ? 'placeholder' : settings.smartDefaultMode;
}

/** Increment "suspended today" counter; badge is updated from current placeholder count. */
async function incrementSuspendedToday() {
  const today = new Date().toISOString().slice(0, 10);
  const { suspendedToday = 0, suspendedTodayDate } = await chrome.storage.local.get(['suspendedToday', 'suspendedTodayDate']);
  const count = suspendedTodayDate === today ? suspendedToday + 1 : 1;
  await chrome.storage.local.set({ suspendedToday: count, suspendedTodayDate: today });
}

/** Number of tabs currently showing the placeholder (suspended.html). */
async function getCurrentlySuspendedTabCount() {
  const tabs = await chrome.tabs.query({});
  return tabs.filter((tab) => tab.url && isPlaceholderTabUrl(tab.url)).length;
}

/** "Hibernated" count: placeholder tabs + "Closed and saved" history entries. Used for badge and popup. */
async function getHibernatedCount() {
  const [tabs, raw] = await Promise.all([
    chrome.tabs.query({}),
    chrome.storage.local.get('closedAndSaved'),
  ]);
  const placeholderCount = tabs.filter(
    (tab) => tab.url && (isPlaceholderTabUrl(tab.url) || isSuspendedPlaceholderUrl(tab.url)),
  ).length;
  const closedSaved = Array.isArray(raw.closedAndSaved) ? raw.closedAndSaved : [];
  return placeholderCount + closedSaved.length;
}

/** Badge on icon: hibernated count (placeholders + closed and saved). */
async function updateBadge(count) {
  try {
    const n = typeof count === 'number' ? count : await getHibernatedCount();
    await chrome.action.setBadgeText({ text: n > 0 ? String(n) : '' });
    if (n > 0) {
      await chrome.action.setBadgeBackgroundColor({ color: '#0d9488' });
    }
  } catch (e) {
    console.warn('[TabHibernate] updateBadge failed', e);
  }
}

function scheduleBadgeUpdate() {
  if (badgeUpdateTimer != null) clearTimeout(badgeUpdateTimer);
  badgeUpdateTimer = setTimeout(() => {
    badgeUpdateTimer = null;
    updateBadge().catch(() => {});
  }, BADGE_UPDATE_DELAY_MS);
}

async function getSuspendedTodayCount() {
  const today = new Date().toISOString().slice(0, 10);
  const { suspendedToday = 0, suspendedTodayDate } = await chrome.storage.local.get(['suspendedToday', 'suspendedTodayDate']);
  return suspendedTodayDate === today ? suspendedToday : 0;
}

/** Remove from storage backup_YYYY-MM-DD keys older than BACKUP_RETENTION_DAYS. */
async function pruneOldBackups() {
  try {
    const { [BACKUP_KEY_CATALOG]: catalog = [] } = await chrome.storage.local.get(BACKUP_KEY_CATALOG);
    const now = new Date();
    const cutoff = new Date(now);
    cutoff.setDate(cutoff.getDate() - BACKUP_RETENTION_DAYS);
    const cutoffStr = cutoff.toISOString().slice(0, 10);
    const keep = [];
    const remove = [];
    for (const key of Array.isArray(catalog) ? catalog : []) {
      const dateStr = key.slice(7);
      if (dateStr.length === 10 && dateStr < cutoffStr) {
        remove.push(key);
      } else keep.push(key);
    }
    if (remove.length) await chrome.storage.local.remove(remove);
    if (keep.length !== catalog.length) await chrome.storage.local.set({ [BACKUP_KEY_CATALOG]: keep });
  } catch (e) {
    console.warn('[TabHibernate] pruneOldBackups failed', e);
  }
}

async function registerBackupKey(storageKey) {
  if (!storageKey.startsWith('backup_')) return;
  const { [BACKUP_KEY_CATALOG]: catalog = [] } = await chrome.storage.local.get(BACKUP_KEY_CATALOG);
  const next = Array.isArray(catalog) ? catalog.slice() : [];
  if (next.includes(storageKey)) return;
  next.push(storageKey);
  await chrome.storage.local.set({ [BACKUP_KEY_CATALOG]: next.slice(-BACKUP_RETENTION_DAYS - 2) });
}

/** Single point to mark tab as active on user action. */
function markTabActive(tabId) {
  const now = Date.now();
  lastActivityByTab.set(tabId, now);
  persistLastActivity(); // fire-and-forget
}

/** Check if timeout minutes have passed since last activity. Tabs with no record (new or not yet in storage) are not treated as inactive to avoid suspending them too soon on alarm. */
function isTabInactive(tabId, timeoutMinutes) {
  const last = lastActivityByTab.get(tabId);
  if (last == null) return false; // unknown tab — do not suspend
  return (Date.now() - last) >= timeoutMinutes * 60 * 1000;
}

/** Discard mode: unload tab via Chrome API. */
async function suspendDiscard(tabId, { deferBadge = false } = {}) {
  try {
    await chrome.tabs.get(tabId);
  } catch (e) {
    return false;
  }
  try {
    await chrome.tabs.discard(tabId);
    await incrementSuspendedToday();
    if (!deferBadge) await updateBadge();
    return true;
  } catch (e) {
    console.warn('[TabHibernate] discard failed', tabId, e);
    return false;
  }
}

/** URL that can be saved and restored (non-empty, not about:blank). */
function hasRestorableUrl(url) {
  const u = (url || '').trim();
  return u.length > 0 && u !== 'about:blank' && !u.startsWith('about:');
}

/** Placeholder mode: save url+title, redirect to suspended.html with ?u= fallback if storage is lost. */
const PLACEHOLDER_URL_PARAM_MAX = 1900;

function getExtensionFaviconUrl(pageUrl, size = 64) {
  try {
    const u = new URL(pageUrl);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return '';
    const faviconUrl = new URL(chrome.runtime.getURL('/_favicon/'));
    faviconUrl.searchParams.set('pageUrl', pageUrl);
    faviconUrl.searchParams.set('size', String(size));
    return faviconUrl.toString();
  } catch (e) {
    return '';
  }
}

function resolveFaviconFetchUrl(url, pageUrl) {
  if (!url) return pageUrl ? getExtensionFaviconUrl(pageUrl) : '';
  if (url.startsWith('data:')) return url;
  if (url.startsWith('chrome://favicon')) return pageUrl ? getExtensionFaviconUrl(pageUrl) : '';
  if (url.startsWith('http://') || url.startsWith('https://')) return url;
  if (url.includes('/_favicon/')) return url;
  return pageUrl ? getExtensionFaviconUrl(pageUrl) : '';
}

async function toDataUrlFromImageUrl(url, pageUrl = '') {
  const fetchUrl = resolveFaviconFetchUrl(url, pageUrl);
  if (!fetchUrl) return '';
  if (fetchUrl.startsWith('data:')) return fetchUrl;
  try {
    const res = await fetch(fetchUrl, { credentials: 'omit', mode: 'cors' });
    if (!res.ok) return '';
    const blob = await res.blob();
    if (!blob || !blob.type || !blob.type.startsWith('image/')) return '';
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(typeof reader.result === 'string' ? reader.result : '');
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
    return typeof dataUrl === 'string' ? dataUrl : '';
  } catch (e) {
    return '';
  }
}

/**
 * Capture a lightweight visual reminder before replacing an active tab.
 * Chrome can only capture the active tab in a window, so background tabs fall
 * back to their title/favicon instead of briefly stealing focus from the user.
 */
async function captureTabPreview(tab) {
  if (!tab?.id || !tab.active || tab.incognito || tab.windowId == null) return '';
  try {
    const window = await chrome.windows.get(tab.windowId);
    if (!window?.focused) return '';
    const source = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: 'jpeg',
      quality: 55,
    });
    if (!source) return '';

    const blob = await (await fetch(source)).blob();
    const bitmap = await createImageBitmap(blob);
    const maxWidth = 960;
    const maxHeight = 600;
    const scale = Math.min(1, maxWidth / bitmap.width, maxHeight / bitmap.height);
    const width = Math.max(1, Math.round(bitmap.width * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = new OffscreenCanvas(width, height);
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) {
      bitmap.close();
      return '';
    }
    try {
      ctx.drawImage(bitmap, 0, 0, width, height);
    } finally {
      bitmap.close();
    }
    const previewBlob = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.62 });
    const previewDataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(typeof reader.result === 'string' ? reader.result : '');
      reader.onerror = reject;
      reader.readAsDataURL(previewBlob);
    });
    canvas.width = 1;
    canvas.height = 1;
    // Avoid one preview monopolising extension storage/heap on very dense or
    // noisy pages. The placeholder still has title, domain and favicon.
    return previewDataUrl.length <= 220_000 ? previewDataUrl : '';
  } catch (e) {
    console.warn('[TabHibernate] preview capture unavailable', e);
    return '';
  }
}

async function persistSuspendedPayload(storageKey, payload) {
  try {
    await chrome.storage.local.set({ [storageKey]: payload });
    return payload;
  } catch (e) {
    if (!isQuotaExceededError(e)) throw e;
    await compactStorageForQuota();
    const compactPayload = { ...payload, favIconUrl: '', previewDataUrl: '' };
    await chrome.storage.local.set({ [storageKey]: compactPayload });
    return compactPayload;
  }
}

async function suspendPlaceholder(tabId, url, title, favIconUrl, meta = {}) {
  let sourceTab;
  try {
    sourceTab = await chrome.tabs.get(tabId);
  } catch (e) {
    return false;
  }
  const safeUrl = url || '';
  const skipFavicon = meta.skipFavicon === true;
  const skipBookmark = meta.skipBookmark === true;
  let captureVisuals = sourceTab.active === true;
  if (captureVisuals) {
    try {
      captureVisuals = (await chrome.windows.get(sourceTab.windowId))?.focused === true;
    } catch (_) {
      captureVisuals = false;
    }
  }
  const [favIconDataUrl, previewDataUrl] = await Promise.all([
    skipFavicon || !captureVisuals
      ? Promise.resolve('')
      : toDataUrlFromImageUrl(favIconUrl || '', safeUrl),
    meta.skipPreview === true || !captureVisuals
      ? Promise.resolve('')
      : captureTabPreview(sourceTab),
  ]);
  const restoreKey = `suspended_${tabId}`;
  const payload = {
    url: safeUrl,
    title: title || '',
    // Background tabs use the lightweight chrome._favicon fallback in the UI
    // instead of persisting thousands of base64 icons.
    favIconUrl: favIconDataUrl || '',
    previewDataUrl,
    tabId,
    ...pickSavedGroupFields(meta),
  };
  if (meta.groupId != null && meta.groupId !== -1) payload.groupId = meta.groupId;
  if (meta.windowId != null) payload.windowId = meta.windowId;
  try {
    const tab = await chrome.tabs.get(tabId);
    if (isTabInGroup(tab)) {
      const gm = await buildGroupMetaMapForTabs([tab]);
      Object.assign(payload, pickSavedGroupFields(gm.get(tabId) || {}));
      if (payload.groupKey) payload.groupKey = normalizeGroupKey(payload.groupKey);
    }
  } catch (_) {}
  const storedPayload = await persistSuspendedPayload(restoreKey, payload);
  await writeSuspendedUrlIndex(storedPayload).catch((e) => {
    console.warn('[TabHibernate] suspended URL index write failed', e);
  });
  if (!skipBookmark) {
    try {
      const folderId = await getOrCreateSuspendedRecoveryFolder();
      await chrome.bookmarks.create({
        parentId: folderId,
        title: (title || safeUrl).slice(0, 255),
        url: safeUrl,
      });
    } catch (e) {
      console.warn('[TabHibernate] suspended bookmark backup failed', e);
    }
  }
  const suspendedUrl = buildSuspendedPlaceholderUrl(tabId, { url: safeUrl });
  try {
    placeholderGroupTransitionUntil.set(tabId, Date.now() + 5000);
    setTimeout(() => placeholderGroupTransitionUntil.delete(tabId), 6000);
    await chrome.tabs.update(tabId, { url: suspendedUrl });
    if (meta.groupId != null && meta.groupId !== -1) {
      try {
        await chrome.tabs.group({ tabIds: [tabId], groupId: meta.groupId });
      } catch (e) {
        console.warn('[TabHibernate] re-group after suspend failed', tabId, e);
      }
    }
    if (storedPayload.groupKey) {
      await applySavedTabGroups(
        [{ tabId, item: storedPayload }],
        { forceRegroup: true },
      );
    }
    await incrementSuspendedToday();
    if (meta.deferBadge !== true) await updateBadge();
    return true;
  } catch (e) {
    console.warn('[TabHibernate] placeholder redirect failed', tabId, e);
    await chrome.storage.local.remove(restoreKey);
    await removeSuspendedUrlIndex(safeUrl);
    return false;
  }
}

/** Get all tabs eligible for backup (same rules as suspend, minus inactivity check). Includes grouped tabs. */
async function getEligibleTabsForBackup() {
  const tabs = await chrome.tabs.query({});
  const eligible = [];
  for (const tab of tabs) {
    if (!tab.url || !tab.id) continue;
    const u = (tab.url || '').toLowerCase();
    if (u.startsWith('chrome://') || u.startsWith('chrome-extension://')) continue;
    if (tab.incognito) continue;
    eligible.push({ id: tab.id, url: tab.url, title: tab.title || tab.url });
  }
  return eligible;
}

function findBookmarkFolder(nodes, title) {
  if (!nodes) return null;
  for (const n of nodes) {
    if (n.title === title) return n;
    const inChild = findBookmarkFolder(n.children || [], title);
    if (inChild) return inChild;
  }
  return null;
}

function getWritableBookmarkParent(root) {
  const children = root?.children || [];
  return children.find((n) => !n.unmodifiable && n.id) || children.find((n) => n.id) || null;
}

/** Create or get "Tab Hibernate / Suspended Recovery" — backup for suspended tabs (survives extension reinstall). */
async function getOrCreateSuspendedRecoveryFolder() {
  const tree = await chrome.bookmarks.getTree();
  const root = tree[0];
  let parent = findBookmarkFolder(root.children, 'Tab Hibernate');
  if (!parent) {
    const writableParent = getWritableBookmarkParent(root);
    if (!writableParent?.id) throw new Error('No writable bookmarks folder');
    const created = await chrome.bookmarks.create({ parentId: writableParent.id, title: 'Tab Hibernate' });
    parent = { id: created.id };
  }
  let folder = findBookmarkFolder([parent], 'Suspended Recovery');
  if (folder?.id) return folder.id;
  const created = await chrome.bookmarks.create({ parentId: parent.id, title: 'Suspended Recovery' });
  return created.id;
}

/** Remove bookmark by URL from Suspended Recovery folder. */
async function removeSuspendedBookmark(url) {
  if (!url) return;
  try {
    const found = await chrome.bookmarks.search({ url });
    const folderId = await getOrCreateSuspendedRecoveryFolder();
    for (const bm of found) {
      if (bm.parentId === folderId) await chrome.bookmarks.remove(bm.id);
    }
  } catch (e) {
    console.warn('[TabHibernate] removeSuspendedBookmark failed', e);
  }
}

/** Create or get bookmarks folder "Tab Backup / YYYY-MM-DD" (parent "Tab Backup", child is date). */
async function getOrCreateBackupFolder() {
  const dateStr = new Date().toISOString().slice(0, 10);
  const tree = await chrome.bookmarks.getTree();
  const root = tree[0];

  let tabBackupRoot = findBookmarkFolder(root.children, 'Tab Backup');
  if (!tabBackupRoot) {
    const writableParent = getWritableBookmarkParent(root);
    if (!writableParent?.id) throw new Error('No writable bookmarks folder');
    const created = await chrome.bookmarks.create({ parentId: writableParent.id, title: 'Tab Backup' });
    tabBackupRoot = { id: created.id, children: [] };
  }
  const dateFolder = findBookmarkFolder([tabBackupRoot], dateStr) || (tabBackupRoot.children && tabBackupRoot.children.find((c) => c.title === dateStr));
  if (dateFolder && dateFolder.id) return dateFolder.id;
  const created = await chrome.bookmarks.create({ parentId: tabBackupRoot.id, title: dateStr });
  return created.id;
}

/** Backup: bookmarks + JSON in storage; skip duplicate URLs in one batch. */
async function runBackup(source = 'manual') {
  const tabs = await getEligibleTabsForBackup();
  const seen = new Set();
  const unique = tabs.filter((t) => {
    const key = normalizeUrlKey(t.url);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
  if (unique.length === 0) return { count: 0, folderId: null, folderPath: null };

  const dateStr = new Date().toISOString().slice(0, 10);
  const folderId = await getOrCreateBackupFolder();
  const folderPath = `Tab Backup / ${dateStr}`;
  const batchId = Date.now();
  const groupMeta = await buildGroupMetaMapForTabs(unique, batchId);

  for (const t of unique) {
    try {
      await chrome.bookmarks.create({ parentId: folderId, title: (t.title || t.url).slice(0, 255), url: t.url });
    } catch (e) {
      console.warn('[TabHibernate] bookmark create failed', t.url, e);
    }
  }

  const backupKey = `backup_${dateStr}`;
  const existing = await chrome.storage.local.get(backupKey);
  const list = existing[backupKey] || [];
  const existingUrls = new Set(list.map((x) => normalizeUrlKey(x.url)));
  for (const t of unique) {
    const key = normalizeUrlKey(t.url);
    if (!key || existingUrls.has(key)) continue;
    let entry = { url: t.url, title: t.title || t.url, ts: Date.now() };
    entry = copyGroupMetaToEntry(entry, groupMeta.get(t.id));
    list.push(entry);
    existingUrls.add(key);
  }
  await persistBoundedList(backupKey, list, BACKUP_ENTRIES_MAX);
  return { count: unique.length, folderId, folderPath };
}

/** Remove closed tab ids from lastActivityByTab to avoid bloating storage. */
async function pruneStaleTabIds() {
  try {
    const tabs = await chrome.tabs.query({});
    const ids = new Set(tabs.map((t) => t.id));
    let changed = false;
    for (const id of lastActivityByTab.keys()) {
      if (!ids.has(id)) {
        lastActivityByTab.delete(id);
        changed = true;
      }
    }
    if (changed) await chrome.storage.local.set({ lastActivityByTab: Object.fromEntries(lastActivityByTab) });
  } catch (e) {
    console.warn('[TabHibernate] pruneStaleTabIds failed', e);
  }
}

const ORPHANED_SUSPENDED_ARCHIVE_MAX = 5000;
const BACKUP_ENTRIES_MAX = 2000;
const EMERGENCY_SESSION_BACKUPS_MAX = 3;

function compactSavedEntry(entry) {
  const out = {
    url: entry.url,
    title: String(entry.title || entry.url || '').slice(0, 512),
  };
  if (entry.ts) out.ts = entry.ts;
  if (entry.savedAt) out.savedAt = entry.savedAt;
  if (entry.domain) out.domain = entry.domain;
  if (entry.reason) out.reason = entry.reason;
  if (Number.isInteger(entry.windowOrder)) out.windowOrder = entry.windowOrder;
  if (Number.isInteger(entry.tabIndex)) out.tabIndex = entry.tabIndex;
  Object.assign(out, pickSavedGroupFields(entry));
  return out;
}

function localDateStamp(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function normalizeDailySnapshotCatalog(value) {
  if (!Array.isArray(value)) return [];
  return value
    .map((entry) => {
      if (typeof entry === 'string') {
        return { key: entry, date: entry.slice(DAILY_SESSION_SNAPSHOT_PREFIX.length) };
      }
      return entry && typeof entry.key === 'string' ? entry : null;
    })
    .filter((entry) => entry?.key?.startsWith(DAILY_SESSION_SNAPSHOT_PREFIX));
}

/** Keep exactly the newest 30 daily recovery points and remove their storage keys. */
async function pruneDailySessionSnapshots() {
  try {
    const stored = await chrome.storage.local.get(DAILY_SESSION_SNAPSHOT_CATALOG);
    const catalog = normalizeDailySnapshotCatalog(stored[DAILY_SESSION_SNAPSHOT_CATALOG]);
    const byKey = new Map(catalog.map((entry) => [entry.key, entry]));
    const sorted = [...byKey.values()].sort((a, b) => String(a.date || '').localeCompare(String(b.date || '')));
    const keep = sorted.slice(-BACKUP_RETENTION_DAYS);
    const keepKeys = new Set(keep.map((entry) => entry.key));
    const remove = sorted.filter((entry) => !keepKeys.has(entry.key)).map((entry) => entry.key);
    if (remove.length) await chrome.storage.local.remove(remove);
    if (remove.length || keep.length !== catalog.length) {
      await chrome.storage.local.set({ [DAILY_SESSION_SNAPSHOT_CATALOG]: keep });
    }
    return keep;
  } catch (e) {
    console.warn('[TabHibernate] pruneDailySessionSnapshots failed', e);
    return [];
  }
}

/** One compact full-session snapshot per local calendar day, including Chrome group metadata. */
async function captureDailySessionSnapshot({ force = false, reason = 'daily' } = {}) {
  if (dailySessionSnapshotPromise) return dailySessionSnapshotPromise;
  dailySessionSnapshotPromise = (async () => {
    const date = localDateStamp();
    const storageKey = `${DAILY_SESSION_SNAPSHOT_PREFIX}${date}`;
    const existing = await chrome.storage.local.get([storageKey, DAILY_SESSION_SNAPSHOT_CATALOG]);
    const catalog = normalizeDailySnapshotCatalog(existing[DAILY_SESSION_SNAPSHOT_CATALOG]);
    if (!force && Array.isArray(existing[storageKey]) && existing[storageKey].length) {
      const meta = catalog.find((entry) => entry.key === storageKey);
      return { created: false, key: storageKey, count: existing[storageKey].length, ...meta };
    }

    const tabs = (await chrome.tabs.query({})).sort((a, b) => (
      (a.windowId - b.windowId) || (a.index - b.index)
    ));
    const context = await buildDomainGroupingContext(tabs);
    const batchId = Date.now();
    const groupMeta = await buildGroupMetaMapForTabs(tabs, batchId);
    const windowOrderById = new Map();
    const seen = new Set();
    const items = [];
    for (const tab of tabs) {
      if (!Number.isInteger(tab.id)) continue;
      const url = resolveBlockerTabPageUrlFromContext(tab, context);
      const urlKey = normalizeUrlKey(url);
      if (!hasRestorableUrl(url) || !urlKey || seen.has(urlKey)) continue;
      seen.add(urlKey);
      if (!windowOrderById.has(tab.windowId)) windowOrderById.set(tab.windowId, windowOrderById.size);
      let entry = {
        url,
        title: tab.title || url,
        savedAt: batchId,
        windowOrder: windowOrderById.get(tab.windowId),
        tabIndex: tab.index,
      };
      entry = copyGroupMetaToEntry(entry, groupMeta.get(tab.id));
      items.push(entry);
    }

    const count = await persistBoundedList(storageKey, items, DAILY_SESSION_SNAPSHOT_MAX_ENTRIES);
    const storedItems = count === items.length ? items : (await chrome.storage.local.get(storageKey))[storageKey] || [];
    const groupCount = new Set(storedItems.map((entry) => entry.groupKey).filter(Boolean)).size;
    const meta = { key: storageKey, date, savedAt: batchId, count, groupCount, reason };
    const nextCatalog = [...catalog.filter((entry) => entry.key !== storageKey), meta]
      .sort((a, b) => String(a.date || '').localeCompare(String(b.date || '')));
    await chrome.storage.local.set({
      [DAILY_SESSION_SNAPSHOT_CATALOG]: nextCatalog,
      lastDailySessionSnapshotAt: batchId,
    });
    await pruneDailySessionSnapshots();
    return { created: true, ...meta };
  })().finally(() => {
    dailySessionSnapshotPromise = null;
  });
  return dailySessionSnapshotPromise;
}

async function persistBoundedList(storageKey, entries, maxEntries, { newestFirst = false } = {}) {
  let next = dedupeEntriesByUrlKey(Array.isArray(entries) ? entries : []).map(compactSavedEntry);
  next = newestFirst ? next.slice(0, maxEntries) : next.slice(-maxEntries);
  while (next.length > 0) {
    try {
      await chrome.storage.local.set({ [storageKey]: next });
      await registerBackupKey(storageKey);
      return next.length;
    } catch (e) {
      if (!isQuotaExceededError(e)) throw e;
      const reducedSize = Math.floor(next.length * 0.75);
      if (reducedSize === next.length) throw e;
      next = newestFirst
        ? next.slice(0, Math.max(1, reducedSize))
        : next.slice(-Math.max(1, reducedSize));
    }
  }
  await chrome.storage.local.set({ [storageKey]: [] });
  await registerBackupKey(storageKey);
  return 0;
}

/** tabIds from placeholder URLs — do not archive even if id no longer matches a live tab. */
function collectPlaceholderReferencedTabIds(tabs) {
  const referenced = new Set();
  for (const tab of tabs) {
    if (!tab?.url) continue;
    if (!isPlaceholderTabUrl(tab.url) && !isSuspendedPlaceholderUrl(tab.url)) continue;
    if (tab.id) referenced.add(tab.id);
    try {
      const u = new URL(tab.url);
      const tid = u.searchParams.get('tabId');
      if (tid) {
        const parsed = Number(tid);
        if (Number.isInteger(parsed)) referenced.add(parsed);
      }
    } catch (_) {}
  }
  return referenced;
}

/** Before deleting orphaned suspended_* keys — archive URL (recover stays populated after extension reload). */
async function archiveOrphanedSuspendedStorage() {
  try {
    const [stored, tabs] = await Promise.all([
      chrome.storage.local.get([SUSPENDED_URL_INDEX, 'orphanedSuspendedArchive']),
      chrome.tabs.query({}),
    ]);
    const aliveIds = new Set(tabs.map((t) => t.id));
    const referencedIds = collectPlaceholderReferencedTabIds(tabs);
    const index = stored[SUSPENDED_URL_INDEX] && typeof stored[SUSPENDED_URL_INDEX] === 'object'
      ? stored[SUSPENDED_URL_INDEX]
      : {};
    const nextIndex = { ...index };
    const archive = [];
    const keysToRemove = [];
    for (const [urlKey, item] of Object.entries(index)) {
      if (archive.length >= ORPHAN_ARCHIVE_BATCH_MAX) break;
      const id = Number(item?.tabId);
      if (!Number.isInteger(id) || aliveIds.has(id) || referencedIds.has(id)) continue;
      const url = item?.url;
      if (url && (url.startsWith('http') || url.startsWith('file'))) {
        archive.push({
          url,
          title: item.title || '',
          archivedAt: Date.now(),
          fromKey: `suspended_${id}`,
          ...pickSavedGroupFields(item),
        });
      }
      keysToRemove.push(`suspended_${id}`);
      delete nextIndex[urlKey];
    }
    if (archive.length) {
      const orphanedSuspendedArchive = Array.isArray(stored.orphanedSuspendedArchive)
        ? stored.orphanedSuspendedArchive
        : [];
      const seen = new Set(orphanedSuspendedArchive.map((x) => normalizeUrlKey(x.url)).filter(Boolean));
      const merged = orphanedSuspendedArchive.slice();
      for (const entry of archive) {
        const key = normalizeUrlKey(entry.url);
        if (!key || seen.has(key)) continue;
        seen.add(key);
        merged.push(entry);
      }
      await persistBoundedList('orphanedSuspendedArchive', merged, ORPHANED_SUSPENDED_ARCHIVE_MAX);
      try {
        const folderId = await getOrCreateEmergencyRecoveryFolder();
        for (const entry of archive) {
          await chrome.bookmarks.create({
            parentId: folderId,
            title: (entry.title || entry.url).slice(0, 255),
            url: entry.url,
          });
        }
      } catch (e) {
        console.warn('[TabHibernate] emergency bookmark archive failed', e);
      }
    }
    if (keysToRemove.length) await chrome.storage.local.remove(keysToRemove);
    if (archive.length) await persistSuspendedUrlIndex(nextIndex);
  } catch (e) {
    console.warn('[TabHibernate] archiveOrphanedSuspendedStorage failed', e);
  }
}

/** Rebind placeholders before archive (otherwise post-restart alarm deletes live suspended_*). */
async function pruneStaleSuspendedEntries() {
  await rebindPlaceholderStorageKeys();
  await archiveOrphanedSuspendedStorage();
}

async function getOrCreateEmergencyRecoveryFolder() {
  const tree = await chrome.bookmarks.getTree();
  const root = tree[0];
  let parent = findBookmarkFolder(root.children, 'Tab Hibernate');
  if (!parent) {
    const writableParent = getWritableBookmarkParent(root);
    if (!writableParent?.id) throw new Error('No writable bookmarks folder');
    const created = await chrome.bookmarks.create({ parentId: writableParent.id, title: 'Tab Hibernate' });
    parent = { id: created.id };
  }
  let folder = findBookmarkFolder([parent], 'Emergency Recovery');
  if (folder?.id) return folder.id;
  const created = await chrome.bookmarks.create({ parentId: parent.id, title: 'Emergency Recovery' });
  return created.id;
}

/** Snapshot all restorable tabs before extension update. */
async function runEmergencySessionBackup(reason = 'manual') {
  try {
    await captureDailySessionSnapshot({ reason });
    const tabs = await chrome.tabs.query({});
    const seen = new Set();
    const items = [];
    const batchId = Date.now();
    const groupMeta = await buildGroupMetaMapForTabs(tabs, batchId);
    for (const tab of tabs) {
      if (!tab?.id) continue;
      let url = tab.pendingUrl || tab.url || '';
      if (isPlaceholderTabUrl(url) || isSuspendedPlaceholderUrl(url)) {
        url = (await getPlaceholderRestoreUrl(tab)) || '';
        if (!url) {
          try {
            const u = new URL(tab.url || '');
            url = u.searchParams.get('u') || '';
          } catch (_) {}
        }
      }
      if (!hasRestorableUrl(url) || seen.has(url)) continue;
      seen.add(url);
      let entry = {
        url,
        title: tab.title || url,
        windowId: tab.windowId,
      };
      entry = copyGroupMetaToEntry(entry, groupMeta.get(tab.id));
      items.push(entry);
    }
    if (!items.length) return { count: 0 };

    const snapshot = { savedAt: Date.now(), reason, items };
    const { emergencySessionBackups = [] } = await chrome.storage.local.get('emergencySessionBackups');
    const nextBackups = [...emergencySessionBackups, snapshot].slice(-EMERGENCY_SESSION_BACKUPS_MAX);
    await chrome.storage.local.set({ emergencySessionBackups: nextBackups, lastEmergencyBackupAt: snapshot.savedAt });

    try {
      const folderId = await getOrCreateEmergencyRecoveryFolder();
      const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const batchFolder = await chrome.bookmarks.create({
        parentId: folderId,
        title: `${stamp} (${reason})`,
      });
      for (const item of items) {
        await chrome.bookmarks.create({
          parentId: batchFolder.id,
          title: (item.title || item.url).slice(0, 255),
          url: item.url,
        });
      }
    } catch (e) {
      console.warn('[TabHibernate] emergency session bookmarks failed', e);
    }

    const dateStr = new Date().toISOString().slice(0, 10);
    await runBackup('emergency');
    return { count: items.length, dateStr };
  } catch (e) {
    console.warn('[TabHibernate] runEmergencySessionBackup failed', e);
    return { count: 0, error: String(e?.message || e) };
  }
}

/** All URLs for Recover: storage, archives, bookmarks (not only suspended_*). */
async function collectRecoverableTabItems() {
  const seen = new Set();
  const items = [];
  const add = (urlOrEntry, title = '') => {
    const entry = typeof urlOrEntry === 'object' && urlOrEntry?.url ? urlOrEntry : { url: urlOrEntry, title };
    const url = entry.url;
    const key = normalizeUrlKey(url);
    if (!url || !(url.startsWith('http') || url.startsWith('file')) || !key || seen.has(key)) return;
    seen.add(key);
    items.push({ url, title: entry.title || '', ...pickSavedGroupFields(entry) });
  };

  const base = await chrome.storage.local.get([
    SUSPENDED_URL_INDEX,
    'orphanedSuspendedArchive',
    'closedAndSaved',
    'blockedTabsSaved',
    'emergencySessionBackups',
    BACKUP_KEY_CATALOG,
    DAILY_SESSION_SNAPSHOT_CATALOG,
  ]);
  for (const entry of Object.values(base[SUSPENDED_URL_INDEX] || {})) add(entry);
  for (const entry of base.orphanedSuspendedArchive || []) add(entry);
  for (const entry of base.closedAndSaved || []) add(entry);
  for (const entry of base.blockedTabsSaved || []) add(entry);
  for (const snap of base.emergencySessionBackups || []) {
    for (const entry of snap.items || []) add(entry);
  }
  const dailySnapshots = normalizeDailySnapshotCatalog(base[DAILY_SESSION_SNAPSHOT_CATALOG])
    .sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
  if (dailySnapshots.length) {
    const dailyData = await chrome.storage.local.get(dailySnapshots.map((entry) => entry.key));
    for (const snapshot of dailySnapshots) {
      for (const entry of dailyData[snapshot.key] || []) add(entry);
    }
  }
  const backupKeys = Array.isArray(base[BACKUP_KEY_CATALOG]) ? base[BACKUP_KEY_CATALOG] : [];
  if (backupKeys.length) {
    const backups = await chrome.storage.local.get(backupKeys);
    for (const key of backupKeys) {
      for (const entry of backups[key] || []) add(entry);
    }
  }

  const bookmarkRoots = new Set(['Tab Hibernate', 'Tab Backup', 'Suspended Recovery', 'Emergency Recovery', 'Site Blocker']);
  try {
    const tree = await chrome.bookmarks.getTree();
    const walk = (nodes, insideBackupTree) => {
      if (!nodes) return;
      for (const n of nodes) {
        if (n.url) add(n.url, n.title);
        const enter = insideBackupTree
          || bookmarkRoots.has(n.title)
          || (n.title && /^\d{4}-\d{2}-\d{2}/.test(n.title))
          || (n.title && /^\d{4}-\d{2}-\d{2}T/.test(n.title));
        if (enter) walk(n.children, true);
      }
    };
    walk(tree[0]?.children, false);
  } catch (e) {
    console.warn('[TabHibernate] collectRecoverable bookmark walk failed', e);
  }

  return items;
}

/** Delay between tabs in batch suspend to avoid freezing the browser. */
const SUSPEND_BATCH_DELAY_MS = 80;

/** Manually suspend all eligible tabs (no inactivity timeout check). Batched with delay to avoid browser freeze. */
async function runSuspendAllNow() {
  await captureDailySessionSnapshot({ reason: 'before-suspend-all' });
  await getStoredState();
  const settings = await getSettings();
  const tabs = await chrome.tabs.query({});
  const groupMeta = await buildGroupMetaMapForTabs(tabs, Date.now());
  const toBackup = [];
  const suspendedPairs = [];
  let suspended = 0;
  for (const tab of tabs) {
    if (!(await isTabEligibleForSuspend(tab, { settings }))) continue;
    if (isTabExcludedByDomain(tab, settings.excludedDomains)) continue;
    const mode = getSuspendModeForTab(settings, tab);
    if (mode === 'placeholder' && !hasRestorableUrl(tab.url)) continue;
    if (mode === 'discard') {
      const ok = await suspendDiscard(tab.id, { deferBadge: true });
      if (ok) {
        toBackup.push({ url: tab.url, title: tab.title });
        suspended++;
      }
    } else {
      const ok = await suspendPlaceholder(tab.id, tab.url, tab.title, tab.favIconUrl, {
        groupId: tab.groupId,
        windowId: tab.windowId,
        deferBadge: true,
        ...pickSavedGroupFields(groupMeta.get(tab.id)),
      });
      if (ok) {
        toBackup.push({ url: tab.url, title: tab.title });
        suspendedPairs.push({ tabId: tab.id, item: groupMeta.get(tab.id) });
        suspended++;
      }
    }
    if (suspended > 0 && suspended % 20 === 0) {
      await new Promise((r) => setTimeout(r, SUSPEND_BATCH_DELAY_MS));
    }
  }
  await applySavedTabGroups(suspendedPairs, { forceRegroup: true });
  await updateBadge();
  if (toBackup.length > 0) {
    const seen = new Set();
    const unique = toBackup.filter((t) => {
      const key = normalizeUrlKey(t.url);
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
    const folderId = await getOrCreateBackupFolder();
    for (const t of unique) {
      try {
        await chrome.bookmarks.create({
          parentId: folderId,
          title: (t.title || t.url).slice(0, 255),
          url: t.url,
        });
      } catch (e) {
        console.warn('[TabHibernate] backup bookmark failed', e);
      }
    }
    const backupKey = `backup_${new Date().toISOString().slice(0, 10)}`;
    const existing = await chrome.storage.local.get(backupKey);
    const list = existing[backupKey] || [];
    const existingUrls = new Set(list.map((x) => normalizeUrlKey(x.url)).filter(Boolean));
    for (const t of unique) {
      const key = normalizeUrlKey(t.url);
      if (key && !existingUrls.has(key)) {
        list.push({ url: t.url, title: t.title || t.url, ts: Date.now() });
        existingUrls.add(key);
      }
    }
    await persistBoundedList(backupKey, list, BACKUP_ENTRIES_MAX);
  }
  return { suspended };
}

/** Placeholder restore URL: storage by tab.id, tabId in URL, or ?u= */
async function getPlaceholderRestoreUrl(tab) {
  if (!tab?.url) return null;
  if (!isPlaceholderTabUrl(tab.url) && !isSuspendedPlaceholderUrl(tab.url)) return null;
  try {
    if (tab.id) {
      const byId = await chrome.storage.local.get(`suspended_${tab.id}`);
      if (byId[`suspended_${tab.id}`]?.url) return byId[`suspended_${tab.id}`].url;
    }
    const u = new URL(tab.url);
    const tid = u.searchParams.get('tabId');
    if (tid) {
      const data = await chrome.storage.local.get(`suspended_${tid}`);
      const item = data[`suspended_${tid}`];
      if (item?.url) return item.url;
    }
    const fallback = u.searchParams.get('u');
    if (fallback && (fallback.startsWith('http') || fallback.startsWith('file'))) return fallback;
  } catch (_) {}
  return null;
}

function buildSuspendedPlaceholderUrl(tabId, item) {
  const params = new URLSearchParams({ tabId: String(tabId) });
  try {
    const original = new URL(item?.url || '');
    if (original.protocol === 'http:' || original.protocol === 'https:') {
      params.set('o', original.origin + '/');
    }
  } catch (_) {}
  if (item?.url && encodeURIComponent(item.url).length <= PLACEHOLDER_URL_PARAM_MAX) {
    params.set('u', item.url);
  }
  return chrome.runtime.getURL('ui-dist/suspended.html') + '?' + params.toString();
}

function getPlaceholderUrlTabId(url) {
  try {
    const raw = new URL(url || '').searchParams.get('tabId');
    const parsed = raw ? parseInt(raw, 10) : null;
    return Number.isInteger(parsed) ? parsed : null;
  } catch (_) {
    return null;
  }
}

async function applyPlaceholderGroupMeta(tab, item) {
  if (!tab?.id || !item) return;
  if (isTabInGroup(tab)) return;
  if (!normalizeGroupKey(item.groupKey)) return;
  const groupId = item.groupId;
  if (groupId == null || groupId === -1) return;
  try {
    await chrome.tabGroups.get(groupId);
    await chrome.tabs.group({ tabIds: [tab.id], groupId });
  } catch (_) {
    /* stale groupId after user ungrouped or Chrome recycled the group */
  }
}

/** Write live Chrome group fields into suspended_* so maintenance does not restore stale titles. */
async function syncSuspendedStorageGroupMetaForTab(tab) {
  if (!tab?.id) return;
  if (!isPlaceholderTabUrl(tab.url) && !isSuspendedPlaceholderUrl(tab.url)) return;
  const storageKey = `suspended_${tab.id}`;
  const urlTabId = getPlaceholderUrlTabId(tab.url);
  const found = await findSuspendedStorageForPlaceholderTab(tab, urlTabId);
  const item = found?.item;
  if (!item?.url) return;

  if (isTabInGroup(tab)) {
    const gm = await buildGroupMetaMapForTabs([tab]);
    const meta = gm.get(tab.id);
    if (meta) {
      await persistSuspendedPayload(storageKey, {
        ...item,
        ...pickSavedGroupFields(meta),
        groupId: tab.groupId,
        tabId: tab.id,
      });
      if (found.oldKey && found.oldKey !== storageKey) await chrome.storage.local.remove(found.oldKey);
    }
    return;
  }

  const oldGroupKey = normalizeGroupKey(item.groupKey);
  const cleared = { ...clearSavedGroupFields(item), tabId: tab.id };
  await persistSuspendedPayload(storageKey, cleared);
  if (found.oldKey && found.oldKey !== storageKey) await chrome.storage.local.remove(found.oldKey);
  if (oldGroupKey) await clearSuspendedGroupMetaByGroupKey(oldGroupKey);
}

async function syncSuspendedStorageGroupMetaForTabIds(tabIds) {
  for (const tabId of tabIds || []) {
    try {
      const tab = await chrome.tabs.get(tabId);
      await syncSuspendedStorageGroupMetaForTab(tab);
    } catch (_) {}
  }
}

const SUSPENDED_URL_INDEX = 'suspendedUrlIndex';
// Keep enough recovery metadata for large sessions. Quota handling below still
// shrinks this dynamically when a browser has a smaller storage allowance.
const SUSPENDED_URL_INDEX_MAX = 5000;

function compactSuspendedUrlIndexEntry(entry) {
  if (!entry?.url) return null;
  const out = {
    url: entry.url,
    title: String(entry.title || '').slice(0, 512),
    tabId: entry.tabId,
    updatedAt: typeof entry.updatedAt === 'number' ? entry.updatedAt : Date.now(),
  };
  Object.assign(out, pickSavedGroupFields(entry));
  if (entry.groupId != null && entry.groupId !== -1 && out.groupKey) out.groupId = entry.groupId;
  if (entry.windowId != null && out.groupKey) out.windowId = entry.windowId;
  return out;
}

async function persistSuspendedUrlIndex(idx) {
  const entries = Object.entries(idx || {})
    .map(([key, value]) => [key, compactSuspendedUrlIndexEntry(value)])
    .filter(([, value]) => value?.url)
    .sort((a, b) => (b[1].updatedAt || 0) - (a[1].updatedAt || 0));
  let keep = entries.slice(0, SUSPENDED_URL_INDEX_MAX);
  while (keep.length > 0) {
    const next = Object.fromEntries(keep);
    try {
      await chrome.storage.local.set({ [SUSPENDED_URL_INDEX]: next });
      return keep.length;
    } catch (e) {
      if (!isQuotaExceededError(e)) throw e;
      const reducedSize = Math.floor(keep.length * 0.75);
      if (reducedSize === keep.length) throw e;
      keep = keep.slice(0, Math.max(1, reducedSize));
    }
  }
  await chrome.storage.local.set({ [SUSPENDED_URL_INDEX]: {} });
  return 0;
}

function mutateSuspendedUrlIndex(mutator) {
  const operation = suspendedUrlIndexMutationChain.then(async () => {
    const { [SUSPENDED_URL_INDEX]: stored = {} } = await chrome.storage.local.get(SUSPENDED_URL_INDEX);
    const idx = stored && typeof stored === 'object' ? { ...stored } : {};
    const changed = await mutator(idx);
    if (changed === false) return false;
    await persistSuspendedUrlIndex(idx);
    return true;
  });
  suspendedUrlIndexMutationChain = operation.catch((e) => {
    console.warn('[TabHibernate] suspended URL index mutation failed', e);
  });
  return operation;
}

async function compactSuspendedUrlIndex() {
  try {
    const { [SUSPENDED_URL_INDEX]: idx = {} } = await chrome.storage.local.get(SUSPENDED_URL_INDEX);
    if (!idx || typeof idx !== 'object') return 0;
    return await persistSuspendedUrlIndex(idx);
  } catch (e) {
    console.warn('[TabHibernate] compactSuspendedUrlIndex failed', e);
    return 0;
  }
}

async function compactStorageForQuota() {
  try {
    await compactSuspendedUrlIndex();
    const baseKeys = [
      'orphanedSuspendedArchive',
      'closedAndSaved',
      'blockedTabsSaved',
      BACKUP_KEY_CATALOG,
    ];
    const base = await chrome.storage.local.get(baseKeys);
    if (Array.isArray(base.orphanedSuspendedArchive)) {
      await persistBoundedList(
        'orphanedSuspendedArchive',
        base.orphanedSuspendedArchive,
        ORPHANED_SUSPENDED_ARCHIVE_MAX,
      );
    }
    if (Array.isArray(base.closedAndSaved)) {
      await persistBoundedList('closedAndSaved', base.closedAndSaved, CLOSED_SAVED_MAX, { newestFirst: true });
    }
    if (Array.isArray(base.blockedTabsSaved)) {
      await persistBoundedList('blockedTabsSaved', base.blockedTabsSaved, BLOCKED_TABS_SAVED_MAX);
    }
    const backupKeys = Array.isArray(base[BACKUP_KEY_CATALOG]) ? base[BACKUP_KEY_CATALOG] : [];
    if (backupKeys.length) {
      const backups = await chrome.storage.local.get(backupKeys);
      for (const key of backupKeys) {
        if (Array.isArray(backups[key])) await persistBoundedList(key, backups[key], BACKUP_ENTRIES_MAX);
      }
    }
  } catch (e) {
    console.warn('[TabHibernate] compactStorageForQuota failed', e);
  }
}

async function writeSuspendedUrlIndex(payload) {
  if (!payload?.url) return;
  const uk = normalizeUrlKey(payload.url);
  if (!uk) return;
  await mutateSuspendedUrlIndex((idx) => {
    idx[uk] = compactSuspendedUrlIndexEntry({
      url: payload.url,
      title: payload.title || '',
      groupKey: payload.groupKey,
      groupTitle: payload.groupTitle,
      groupColor: payload.groupColor,
      groupCollapsed: payload.groupCollapsed,
      tabIndexInGroup: payload.tabIndexInGroup,
      groupId: payload.groupId,
      windowId: payload.windowId,
      tabId: payload.tabId,
      updatedAt: Date.now(),
    });
  });
}

async function lookupSuspendedUrlIndex(url) {
  const uk = normalizeUrlKey(url);
  if (!uk) return null;
  const { [SUSPENDED_URL_INDEX]: idx = {} } = await chrome.storage.local.get(SUSPENDED_URL_INDEX);
  const hit = idx[uk];
  return hit?.url ? hit : null;
}

async function removeSuspendedUrlIndex(url) {
  const uk = normalizeUrlKey(url);
  if (!uk) return;
  await mutateSuspendedUrlIndex((idx) => {
    if (!idx[uk]) return false;
    delete idx[uk];
    return true;
  });
}

async function clearSuspendedGroupMetaByGroupKey(groupKey) {
  const normalized = normalizeGroupKey(groupKey);
  if (!normalized) return;

  const { [SUSPENDED_URL_INDEX]: idx = {} } = await chrome.storage.local.get(SUSPENDED_URL_INDEX);
  const updates = {};
  let hasUpdates = false;
  if (idx && typeof idx === 'object') {
    let changed = false;
    const nextIdx = { ...idx };
    const suspendedKeys = [];
    for (const [urlKey, val] of Object.entries(nextIdx)) {
      if (!val || typeof val !== 'object' || normalizeGroupKey(val.groupKey) !== normalized) continue;
      nextIdx[urlKey] = clearSavedGroupFields(val);
      if (Number.isInteger(val.tabId)) suspendedKeys.push(`suspended_${val.tabId}`);
      changed = true;
    }
    if (changed) {
      updates[SUSPENDED_URL_INDEX] = nextIdx;
      hasUpdates = true;
    }
    if (suspendedKeys.length) {
      const suspended = await chrome.storage.local.get(suspendedKeys);
      for (const key of suspendedKeys) {
        if (suspended[key]?.url) updates[key] = clearSavedGroupFields(suspended[key]);
      }
    }
  }

  if (hasUpdates) await chrome.storage.local.set(updates);
}

/** Find suspended_* after Chrome session restore changes tab.id. */
async function findSuspendedStorageForPlaceholderTab(tab, urlTabId) {
  if (!tab?.id) return null;
  const directKeys = [`suspended_${tab.id}`];
  if (urlTabId != null && !Number.isNaN(urlTabId) && urlTabId !== tab.id) {
    directKeys.push(`suspended_${urlTabId}`);
  }
  const direct = await chrome.storage.local.get(directKeys);
  for (const key of directKeys) {
    if (direct[key]?.url) {
      return { item: direct[key], oldKey: key !== `suspended_${tab.id}` ? key : null };
    }
  }

  let fallbackUrl = '';
  try {
    fallbackUrl = new URL(tab.url || '').searchParams.get('u') || '';
  } catch (_) {}
  if (fallbackUrl && hasRestorableUrl(fallbackUrl)) {
    const indexed = await lookupSuspendedUrlIndex(fallbackUrl);
    if (indexed?.url) {
      return {
        item: { ...indexed, tabId: tab.id },
        oldKey: urlTabId != null && !Number.isNaN(urlTabId) ? `suspended_${urlTabId}` : null,
      };
    }
    return {
      item: { url: fallbackUrl, title: tab.title || '', favIconUrl: '', tabId: tab.id },
      oldKey: urlTabId != null && !Number.isNaN(urlTabId) ? `suspended_${urlTabId}` : null,
    };
  }

  const { [SUSPENDED_URL_INDEX]: index = {} } = await chrome.storage.local.get(SUSPENDED_URL_INDEX);
  for (const val of Object.values(index && typeof index === 'object' ? index : {})) {
    if (!val || typeof val !== 'object' || !val.url) continue;
    if (val.tabId === tab.id || (urlTabId != null && val.tabId === urlTabId)) {
      const oldKey = val.tabId !== tab.id ? `suspended_${val.tabId}` : null;
      return { item: { ...val, tabId: tab.id }, oldKey };
    }
  }
  return null;
}

/** Rebind one placeholder to current tab.id and restore its Chrome group. */
async function rebindSinglePlaceholderTab(tab) {
  if (!tab?.id || !tab.url) return false;
  if (!isPlaceholderTabUrl(tab.url) && !isSuspendedPlaceholderUrl(tab.url)) return false;

  let urlTabId = null;
  try {
    const raw = new URL(tab.url).searchParams.get('tabId');
    urlTabId = raw ? parseInt(raw, 10) : null;
  } catch (_) {
    return false;
  }

  const found = await findSuspendedStorageForPlaceholderTab(tab, urlTabId);
  if (!found?.item?.url) return false;

  const item = { ...found.item, tabId: tab.id };
  if (item.groupKey) item.groupKey = normalizeGroupKey(item.groupKey);
  const currentKey = `suspended_${tab.id}`;
  const newUrl = buildSuspendedPlaceholderUrl(tab.id, item);
  const existing = await chrome.storage.local.get(currentKey);
  const needsStorage = found.oldKey != null || !existing[currentKey]?.url;
  let needsUrlUpdate = true;
  try {
    const current = new URL(tab.url);
    const expected = new URL(newUrl);
    // Chrome assigns new tab IDs after session restore. The current extension
    // page can keep its old query string: storage is rebound to sender.tab.id
    // and all restore paths already check both IDs. Navigating only to rewrite
    // tabId/u needlessly flashes the whole document.
    needsUrlUpdate = current.protocol !== expected.protocol
      || current.host !== expected.host
      || current.pathname !== expected.pathname;
  } catch (_) {}

  if (needsStorage) {
    const storedItem = await persistSuspendedPayload(currentKey, item);
    await writeSuspendedUrlIndex(storedItem).catch((e) => {
      console.warn('[TabHibernate] suspended URL index write failed', e);
    });
  }
  if (found.oldKey && found.oldKey !== currentKey) {
    await chrome.storage.local.remove(found.oldKey);
  }

  if (needsUrlUpdate) {
    if (tab.discarded) {
      // Do not update URL of discarded tabs to prevent them from loading as blank pages.
      // The URL will be updated later when the tab is activated/loaded and sends resolvePlaceholderData.
    } else {
      await chrome.tabs.update(tab.id, { url: newUrl });
    }
  } else if (needsStorage) {
    chrome.tabs.sendMessage(tab.id, { type: 'placeholderRefresh' }).catch(() => {});
  }

  if (needsStorage || needsUrlUpdate) {
    try {
      const updated = await chrome.tabs.get(tab.id);
      await applyPlaceholderGroupMeta(updated, item);
    } catch (_) {
      await applyPlaceholderGroupMeta(tab, item);
    }
  }
  return true;
}

/** Max rows in closedAndSaved; dedupe by URL key when saving placeholders. */
const CLOSED_SAVED_MAX = 10000;

/** URL dedupe key: host + path + ?query; hash (#) ignored; different path/query = different URL. */
function urlKeyForHistory(url) {
  try {
    const u = new URL(url);
    u.hash = '';
    if (u.protocol === 'file:') return `file:${u.pathname}`;
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return '';
    const host = u.hostname.replace(/^www\./i, '').toLowerCase();
    let path = u.pathname;
    if (path.length > 1 && path.endsWith('/')) path = path.slice(0, -1);
    return `${host}${path}${u.search}`;
  } catch (_) {
    return '';
  }
}

function normalizeUrlKey(url) {
  if (!url) return '';
  const key = urlKeyForHistory(url);
  return key || String(url).trim();
}

/** Keep first occurrence of each URL key (lists are newest-first). */
function dedupeEntriesByUrlKey(entries) {
  const indexByKey = new Map();
  const out = [];
  for (const entry of entries) {
    if (!entry?.url) continue;
    const key = normalizeUrlKey(entry.url);
    if (!key) continue;
    if (indexByKey.has(key)) {
      const index = indexByKey.get(key);
      if (!out[index].groupKey && entry.groupKey) {
        out[index] = { ...out[index], ...pickSavedGroupFields(entry) };
      }
      continue;
    }
    indexByKey.set(key, out.length);
    out.push(entry);
  }
  return out;
}

async function pruneDuplicateSavedLists() {
  try {
    const storageKeys = ['closedAndSaved', 'blockedTabsSaved', 'orphanedSuspendedArchive'];
    const stored = await chrome.storage.local.get(storageKeys);
    const keptByUrl = new Map();
    const patch = {};
    let removed = 0;

    // Source priority matches the History UI: regular saved tabs, Site
    // Blocker saves, then the recovery archive. Keep the first canonical URL.
    for (const storageKey of storageKeys) {
      const list = Array.isArray(stored[storageKey]) ? stored[storageKey] : [];
      const unique = [];
      for (const entry of list) {
        const key = normalizeUrlKey(entry?.url);
        if (!key) {
          removed++;
          continue;
        }
        const kept = keptByUrl.get(key);
        if (kept) {
          removed++;
          if (!kept.entry.groupKey && entry?.groupKey) {
            kept.entry = { ...kept.entry, ...pickSavedGroupFields(entry) };
            kept.list[kept.index] = kept.entry;
            patch[kept.storageKey] = kept.list;
          }
          continue;
        }
        keptByUrl.set(key, {
          storageKey,
          list: unique,
          index: unique.length,
          entry,
        });
        unique.push(entry);
      }
      if (unique.length !== list.length) patch[storageKey] = unique;
    }
    if (Object.keys(patch).length) await chrome.storage.local.set(patch);
    return { removed };
  } catch (e) {
    console.warn('[TabHibernate] pruneDuplicateSavedLists failed', e);
    return { removed: 0, error: String(e?.message || e) };
  }
}

function isQuotaExceededError(error) {
  if (!error) return false;
  const message = String(error.message || error).toLowerCase();
  return message.includes('quota') || message.includes('max write operations');
}

async function persistClosedAndSaved(entries) {
  let next = dedupeEntriesByUrlKey(Array.isArray(entries) ? entries : []).slice(0, CLOSED_SAVED_MAX);
  while (next.length > 0) {
    try {
      await chrome.storage.local.set({ closedAndSaved: next });
      return next.length;
    } catch (e) {
      if (!isQuotaExceededError(e)) throw e;
      // Keep newest entries and shrink aggressively to fit storage limits.
      const reducedSize = Math.floor(next.length * 0.8);
      if (reducedSize === next.length) throw e;
      next = next.slice(0, Math.max(1, reducedSize));
    }
  }
  await chrome.storage.local.set({ closedAndSaved: [] });
  return 0;
}
async function runCloseAndSaveAll() {
  await captureDailySessionSnapshot({ reason: 'before-close-and-save-all' });
  const settings = await getSettings();
  const tabs = await chrome.tabs.query({});
  const toSave = [];
  const idsToClose = [];
  const seenUrls = new Set();
  const batchId = Date.now();
  const candidateTabs = [];
  let scanned = 0;
  const setProgress = async (extra = {}) => {
    try {
      await chrome.storage.local.set({
        closeAndSaveProgress: {
          stage: extra.stage || 'scanning',
          scanned,
          totalCandidates: toSave.length,
          totalToClose: idsToClose.length,
          closed: extra.closed || 0,
          saved: extra.saved || 0,
        },
      });
    } catch (_) {}
  };
  await setProgress({ stage: 'scanning' });
  for (const tab of tabs) {
    scanned++;
    let url = '';
    let title = '';
    if (isPlaceholderTabUrl(tab.url)) {
      url = await getPlaceholderRestoreUrl(tab) || '';
      title = (tab.title || url || '').slice(0, 512);
    } else if (await isTabEligibleForSuspend(tab, { settings })) {
      url = tab.url || '';
      title = (tab.title || tab.url || '').slice(0, 512);
    } else {
      continue;
    }
    if (!url) continue;
    candidateTabs.push({ tab, url, title });
    if (scanned % 25 === 0) await setProgress({ stage: 'scanning' });
  }
  const groupMeta = await buildGroupMetaMapForTabs(candidateTabs.map((c) => c.tab), batchId);
  for (const { tab, url, title } of candidateTabs) {
    const urlKey = normalizeUrlKey(url);
    if (seenUrls.has(urlKey)) {
      idsToClose.push(tab.id);
      continue;
    }
    seenUrls.add(urlKey);
    let entry = { url, title, savedAt: Date.now() };
    entry = copyGroupMetaToEntry(entry, groupMeta.get(tab.id));
    toSave.push(entry);
    idsToClose.push(tab.id);
  }
  await setProgress({ stage: 'scanning' });
  if (idsToClose.length === 0) return { closed: 0 };
  const { closedAndSaved = [] } = await chrome.storage.local.get('closedAndSaved');
  const mergedUrls = new Set(toSave.map((x) => normalizeUrlKey(x.url)));
  const uniqueExisting = closedAndSaved.filter((x) => x.url && !mergedUrls.has(normalizeUrlKey(x.url)));
  const merged = [...toSave.reverse(), ...uniqueExisting];
  const savedCount = await persistClosedAndSaved(merged);
  await setProgress({ stage: 'closing', saved: savedCount });
  const CLOSE_BATCH_DELAY_MS = 50;
  let closedCount = 0;
  for (let i = 0; i < idsToClose.length; i++) {
    try { await chrome.tabs.remove(idsToClose[i]); } catch (e) { console.warn('[TabHibernate] tab remove failed', idsToClose[i], e); }
    closedCount++;
    if (closedCount % 20 === 0 || closedCount === idsToClose.length) {
      await setProgress({ stage: 'closing', closed: closedCount, saved: savedCount });
    }
    if ((i + 1) % 30 === 0 && i + 1 < idsToClose.length) {
      await new Promise((r) => setTimeout(r, CLOSE_BATCH_DELAY_MS));
    }
  }
  return { closed: closedCount, saved: savedCount };
}

/** Save tabs of the active Chrome group to History; optionally close them. */
async function runSaveTabGroup({ closeTabs = false } = {}) {
  if (closeTabs) await captureDailySessionSnapshot({ reason: 'before-close-tab-group' });
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!active?.id || !isTabInGroup(active)) {
    return { saved: 0, closed: 0, error: 'no-group' };
  }
  const tabs = (await chrome.tabs.query({ groupId: active.groupId })).sort((a, b) => a.index - b.index);
  const batchId = Date.now();
  const groupMeta = await buildGroupMetaMapForTabs(tabs, batchId);
  const toSave = [];
  const idsToClose = [];
  const seenUrls = new Set();
  for (const tab of tabs) {
    let url = '';
    let title = '';
    if (isPlaceholderTabUrl(tab.url) || isSuspendedPlaceholderUrl(tab.url)) {
      url = (await getPlaceholderRestoreUrl(tab)) || '';
      title = (tab.title || url || '').slice(0, 512);
    } else if (hasRestorableUrl(tab.url)) {
      url = tab.url;
      title = (tab.title || tab.url || '').slice(0, 512);
    }
    if (!url) continue;
    const urlKey = normalizeUrlKey(url);
    if (seenUrls.has(urlKey)) {
      if (closeTabs) idsToClose.push(tab.id);
      continue;
    }
    seenUrls.add(urlKey);
    let entry = { url, title, savedAt: Date.now() };
    entry = copyGroupMetaToEntry(entry, groupMeta.get(tab.id));
    toSave.push(entry);
    if (closeTabs) idsToClose.push(tab.id);
  }
  if (!toSave.length) return { saved: 0, closed: 0, error: 'empty' };
  const { closedAndSaved = [] } = await chrome.storage.local.get('closedAndSaved');
  const mergedUrls = new Set(toSave.map((x) => normalizeUrlKey(x.url)));
  const uniqueExisting = closedAndSaved.filter((x) => x.url && !mergedUrls.has(normalizeUrlKey(x.url)));
  const savedCount = await persistClosedAndSaved([...toSave.reverse(), ...uniqueExisting]);
  let closedCount = 0;
  if (closeTabs) {
    for (const id of idsToClose) {
      try {
        await chrome.tabs.remove(id);
        closedCount++;
      } catch (e) {
        console.warn('[TabHibernate] close tab group tab failed', id, e);
      }
    }
  }
  await updateBadge();
  return { saved: toSave.length, closed: closedCount, persisted: savedCount };
}

let closeAndSaveJobRunning = false;
async function startCloseAndSaveAllJob() {
  if (closeAndSaveJobRunning) return { started: false, reason: 'already-running' };
  closeAndSaveJobRunning = true;
  await chrome.storage.local.remove('closeAndSaveResult').catch(() => {});
  runCloseAndSaveAll().then(async (res) => {
    await chrome.storage.local.set({ closeAndSaveResult: { ok: true, ...res, finishedAt: Date.now() } });
    await chrome.storage.local.remove('closeAndSaveProgress');
    await updateBadge();
  }).catch(async (e) => {
    console.warn('[TabHibernate] closeAndSaveAll async job failed', e);
    await chrome.storage.local.set({
      closeAndSaveResult: { ok: false, closed: 0, saved: 0, error: String(e?.message || e), finishedAt: Date.now() },
    });
    await chrome.storage.local.remove('closeAndSaveProgress');
  }).finally(() => {
    closeAndSaveJobRunning = false;
  });
  return { started: true };
}

/** Delay between restores (ms) — avoid memory spike. */
const RESTORE_DELAY_MS = 1000;
const RESTORE_COMMIT_TIMEOUT_MS = 20000;
const PENDING_RESTORE_PREFIX = 'pending_restore_';
const PENDING_RESTORE_MAX_AGE_MS = 60 * 1000;
const RESTORE_ALLOW_RULE_ID_START = 1_000_000;
const RESTORE_ALLOW_RULE_ALARM_PREFIX = 'swissRestoreAllow:';
const RESTORE_ALLOW_RULE_TTL_MS = 60 * 1000;

function pendingRestoreKey(tabId) {
  return `${PENDING_RESTORE_PREFIX}${tabId}`;
}

async function removeRestoreAllowRule(ruleId) {
  if (!Number.isInteger(ruleId)) return;
  await chrome.alarms.clear(`${RESTORE_ALLOW_RULE_ALARM_PREFIX}${ruleId}`).catch(() => {});
  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [ruleId] }).catch(() => {});
}

async function installRestoreAllowRule(tabId, url) {
  if (!Number.isInteger(tabId)) return null;
  let hostname = '';
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return null;
    hostname = parsed.hostname;
  } catch (_) {
    return null;
  }
  const existing = await chrome.declarativeNetRequest.getSessionRules();
  const usedIds = new Set(existing.map((rule) => rule.id));
  let ruleId = RESTORE_ALLOW_RULE_ID_START + (Math.abs(tabId) % 1_000_000_000);
  while (usedIds.has(ruleId)) ruleId++;
  await chrome.declarativeNetRequest.updateSessionRules({
    addRules: [{
      id: ruleId,
      priority: 100_000,
      action: { type: 'allowAllRequests' },
      condition: {
        requestDomains: [hostname],
        tabIds: [tabId],
        resourceTypes: ['main_frame'],
      },
    }],
  });
  await chrome.alarms.create(`${RESTORE_ALLOW_RULE_ALARM_PREFIX}${ruleId}`, {
    when: Date.now() + RESTORE_ALLOW_RULE_TTL_MS,
  });
  return ruleId;
}

async function clearRestoredTabData(url, keys) {
  await Promise.all([
    chrome.storage.local.remove(keys),
    removeSuspendedBookmark(url),
    removeSuspendedUrlIndex(url),
  ]);
  await updateBadge();
}

function navigateTabAndWaitForCommit(tabId, url) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      chrome.webNavigation.onCommitted.removeListener(onCommitted);
      chrome.webNavigation.onErrorOccurred.removeListener(onError);
      if (error) reject(error);
      else resolve();
    };
    const onCommitted = (details) => {
      if (details.tabId !== tabId || !SwissCore.isSuccessfulRestoreCommit(details)) return;
      finish();
    };
    const onError = (details) => {
      if (details.tabId !== tabId || details.frameId !== 0) return;
      finish(new Error(details.error || 'Navigation failed'));
    };
    const timer = setTimeout(
      () => finish(new Error('Restore navigation timed out; recovery data was kept.')),
      RESTORE_COMMIT_TIMEOUT_MS,
    );
    chrome.webNavigation.onCommitted.addListener(onCommitted);
    chrome.webNavigation.onErrorOccurred.addListener(onError);
    chrome.tabs.update(tabId, { url }).catch(finish);
  });
}

/** Restore all tabs: one at a time with delay, writes restoreProgress to storage. */
async function runRestoreAllSuspended() {
  const tabs = await chrome.tabs.query({});
  const placeholders = [];
  for (const tab of tabs) {
    if (!tab.url || !tab.id) continue;
    if (!isPlaceholderTabUrl(tab.url) && !isSuspendedPlaceholderUrl(tab.url)) continue;
    let u = null;
    let tid = null;
    try {
      u = new URL(tab.url);
      const tabIdParam = u.searchParams.get('tabId');
      tid = tabIdParam ? parseInt(tabIdParam, 10) : null;
    } catch (_) {}
    placeholders.push({ tab, tid: Number.isNaN(tid) ? null : tid, u });
  }
  const total = placeholders.length;
  let restored = 0;
  const setProgress = (r, t) => {
    chrome.storage.local.set({
      restoreProgress: { done: r, total: t, remaining: t - r },
    });
  };
  for (const { tab, tid, u } of placeholders) {
    try {
      const found = await findSuspendedStorageForPlaceholderTab(tab, tid);
      let restoreUrl = found?.item?.url || null;
      if (!restoreUrl) {
        const fallback = u?.searchParams?.get('u') || '';
        if (hasRestorableUrl(fallback)) restoreUrl = fallback;
      }
      if (restoreUrl) {
        const unblockResult = await unblockSiteForRestore(restoreUrl, tab.id);
        const keysToRemove = SwissCore.getRestoreStorageKeys(tab.id, tid, found?.oldKey);
        let committed = false;
        try {
          await navigateTabAndWaitForCommit(tab.id, restoreUrl);
          committed = true;
          await clearRestoredTabData(restoreUrl, keysToRemove);
        } finally {
          if (!committed) await removeRestoreAllowRule(unblockResult.allowRuleId);
        }
        restored++;
        setProgress(restored, total);
        if (restored < total) await new Promise((r) => setTimeout(r, RESTORE_DELAY_MS));
      }
    } catch (e) {
      console.warn('[TabHibernate] restore tab failed', tab.id, e);
    }
  }
  await chrome.storage.local.remove('restoreProgress');
  await updateBadge();
  return { restored };
}

/** Discard background tabs — same rules as TabMemoryCleaner (`tmcSettings`). */
const DISCARD_DELAY_MS = 300;
const TMC_DEFAULT_SETTINGS = {
  skipPinned: false,
  skipAudible: true,
  skipIncognito: true,
  skipGrouped: false,
  excludedDomains: [],
};

function tmcNormalizeDomain(input) {
  let s = String(input || '').trim().toLowerCase();
  if (!s) return '';
  try {
    if (!s.startsWith('http')) s = 'https://' + s;
    return new URL(s).hostname.replace(/^www\./, '') || '';
  } catch {
    return s.replace(/^www\./, '').split('/')[0].split('?')[0];
  }
}

function tmcParseExcludedList(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  const seen = new Set();
  for (const item of list) {
    const d = tmcNormalizeDomain(item);
    if (!d || seen.has(d)) continue;
    seen.add(d);
    out.push(d);
  }
  return out;
}

function tmcHostMatchesDomains(host, domains) {
  if (!host || !domains.length) return false;
  const h = host.replace(/^www\./, '').toLowerCase();
  return domains.some((d) => h === d || h.endsWith('.' + d));
}

async function getTmcDiscardSettings() {
  const { tmcSettings = {} } = await chrome.storage.local.get('tmcSettings');
  return {
    ...TMC_DEFAULT_SETTINGS,
    ...tmcSettings,
    excludedDomains: tmcParseExcludedList(tmcSettings.excludedDomains),
  };
}

async function runDiscardBackgroundTabs() {
  const opts = await getTmcDiscardSettings();
  const tabs = await chrome.tabs.query({});
  const toDiscard = tabs.filter((tab) => {
    if (!tab.id) return false;
    const u = (tab.url || '').toLowerCase();
    if (u.startsWith('chrome://') || u.startsWith('chrome-extension://')) return false;
    if (tab.active) return false;
    if (opts.skipPinned && tab.pinned) return false;
    if (opts.skipAudible && tab.audible) return false;
    if (opts.skipIncognito && tab.incognito) return false;
    if (opts.skipGrouped && isTabInGroup(tab)) return false;
    try {
      const host = new URL(tab.url || 'about:blank').hostname;
      if (tmcHostMatchesDomains(host, opts.excludedDomains)) return false;
    } catch (_) {}
    return true;
  });
  let discarded = 0;
  for (const tab of toDiscard) {
    try {
      await chrome.tabs.discard(tab.id);
      discarded++;
      if (discarded < toDiscard.length) await new Promise((r) => setTimeout(r, DISCARD_DELAY_MS));
    } catch (e) {
      console.warn('[Memory] discard failed', tab.id, e);
    }
  }
  return { discarded, total: toDiscard.length };
}

/**
 *    of storage + bookmarks (survives reinstall).
 * From placeholder- (suspended.html),     —  RAM  CPU  100+ .
 * From     «Restore" .
 */
const RECOVER_DELAY_MS = 60;
const HISTORY_OPEN_BATCH_SIZE = 8;

async function runRecoverLostSuspended() {
  const items = await collectRecoverableTabItems();
  if (!items.length) {
    return { recovered: 0, sourcesHint: 'Check Chrome bookmarks: Tab Hibernate → Emergency Recovery / Suspended Recovery, or Tab Backup. Open History in the panel for closed-and-saved lists.' };
  }

  const res = await runOpenUrlsAsPlaceholders(items);
  return { recovered: res.opened, totalCandidates: items.length };
}

async function removeOpenedItemsFromHistory(items) {
  const openedKeys = new Set(
    (items || []).map((item) => normalizeUrlKey(item?.url)).filter(Boolean),
  );
  if (!openedKeys.size) return 0;
  const storageKeys = ['closedAndSaved', 'blockedTabsSaved', 'orphanedSuspendedArchive'];
  const stored = await chrome.storage.local.get(storageKeys);
  const updates = {};
  let removed = 0;
  for (const key of storageKeys) {
    const list = Array.isArray(stored[key]) ? stored[key] : [];
    updates[key] = list.filter((item) => !openedKeys.has(normalizeUrlKey(item?.url)));
    removed += list.length - updates[key].length;
  }
  await chrome.storage.local.set(updates);
  return removed;
}

/** Open URLs as hibernate placeholders; items: [{url, title, groupKey?, ...}]. */
async function runOpenUrlsAsPlaceholders(items, {
  removeFromHistory = false,
  windowId = null,
  existingGroupPairs = [],
} = {}) {
  if (!items || !items.length) return { opened: 0 };
  const alreadyOpenKeys = await getOpenTabUrlKeys();
  const seenOpen = new Set();
  const valid = items
    .filter((x) => x && x.url && (x.url.startsWith('http') || x.url.startsWith('file')))
    .filter((x) => {
      const key = normalizeUrlKey(x.url);
      const openKey = urlKeyForHistory(x.url);
      if (!key || seenOpen.has(key) || (openKey && alreadyOpenKeys.has(openKey))) return false;
      seenOpen.add(key);
      return true;
    })
    .sort((a, b) => {
      const ga = normalizeGroupKey(a.groupKey) || `\xff${a.url}`;
      const gb = normalizeGroupKey(b.groupKey) || `\xff${b.url}`;
      if (ga !== gb) return ga.localeCompare(gb);
      return (a.tabIndexInGroup ?? 0) - (b.tabIndexInGroup ?? 0);
    });
  const created = [];
  let opened = 0;
  let failed = 0;
  const errors = [];
  let destinationWindowId = Number.isInteger(windowId) ? windowId : null;
  if (destinationWindowId == null) {
    try {
      destinationWindowId = (await chrome.windows.getLastFocused())?.id ?? null;
    } catch (_) {}
  }
  await chrome.storage.local.set({
    historyOpenProgress: { processed: 0, opened: 0, failed: 0, total: valid.length },
  });
  try {
    for (let offset = 0; offset < valid.length; offset += HISTORY_OPEN_BATCH_SIZE) {
      const batch = valid.slice(offset, offset + HISTORY_OPEN_BATCH_SIZE);
      const results = await Promise.all(batch.map(async (item) => {
        try {
          const itemWindowId = Number.isInteger(item.restoreWindowId)
            ? item.restoreWindowId
            : destinationWindowId;
          const tab = await openPlaceholderTabForItem(item, itemWindowId);
          return { tab, item };
        } catch (e) {
          return { item, error: String(e?.message || e) };
        }
      }));
      for (const result of results) {
        if (result.tab?.id) {
          created.push({ tabId: result.tab.id, item: result.item });
          opened++;
        } else {
          failed++;
          if (errors.length < 3 && result.error) errors.push(result.error);
        }
      }
      await chrome.storage.local.set({
        historyOpenProgress: {
          processed: Math.min(offset + batch.length, valid.length),
          opened,
          failed,
          total: valid.length,
        },
      });
      if (offset + batch.length < valid.length) {
        await new Promise((r) => setTimeout(r, RECOVER_DELAY_MS));
      }
    }
  } finally {
    await chrome.storage.local.remove('historyOpenProgress');
  }
  await applySavedTabGroups([...existingGroupPairs, ...created], { forceRegroup: true });
  if (removeFromHistory) {
    await removeOpenedItemsFromHistory(created.map(({ item }) => item));
  }
  await updateBadge();
  return { opened, failed, errors, openedItems: created.map(({ item }) => item) };
}

/** Restore a daily point: regroup matching open tabs and open only URLs that are missing. */
async function runRestoreDailySessionSnapshot(storageKey) {
  const catalogData = await chrome.storage.local.get(DAILY_SESSION_SNAPSHOT_CATALOG);
  const catalog = normalizeDailySnapshotCatalog(catalogData[DAILY_SESSION_SNAPSHOT_CATALOG]);
  const meta = catalog.find((entry) => entry.key === storageKey);
  if (!meta) return { opened: 0, regrouped: 0, error: 'Recovery point not found' };
  const stored = await chrome.storage.local.get(storageKey);
  const items = Array.isArray(stored[storageKey]) ? stored[storageKey] : [];
  if (!items.length) return { opened: 0, regrouped: 0, error: 'Recovery point is empty' };

  const tabs = await chrome.tabs.query({});
  const context = await buildDomainGroupingContext(tabs);
  const openByUrl = new Map();
  for (const tab of tabs) {
    const url = resolveBlockerTabPageUrlFromContext(tab, context);
    const key = normalizeUrlKey(url);
    if (key && !openByUrl.has(key)) openByUrl.set(key, tab);
  }

  const focusedWindowId = await getFocusedNormalWindowId();
  const windowBySnapshotOrder = new Map();
  const existingGroupPairs = [];
  const missing = [];
  for (const item of items) {
    const key = normalizeUrlKey(item.url);
    const openTab = key ? openByUrl.get(key) : null;
    if (openTab?.id) {
      existingGroupPairs.push({ tabId: openTab.id, item });
      if (Number.isInteger(item.windowOrder) && !windowBySnapshotOrder.has(item.windowOrder)) {
        windowBySnapshotOrder.set(item.windowOrder, openTab.windowId);
      }
    }
  }
  for (const item of items) {
    const key = normalizeUrlKey(item.url);
    if (key && openByUrl.has(key)) continue;
    const restoreWindowId = Number.isInteger(item.windowOrder)
      ? windowBySnapshotOrder.get(item.windowOrder)
      : null;
    missing.push({
      ...item,
      restoreWindowId: Number.isInteger(restoreWindowId) ? restoreWindowId : focusedWindowId,
    });
  }

  if (!missing.length) {
    await applySavedTabGroups(existingGroupPairs, { forceRegroup: true });
    return { opened: 0, regrouped: existingGroupPairs.length, total: items.length, date: meta.date };
  }
  const result = await runOpenUrlsAsPlaceholders(missing, { existingGroupPairs });
  return {
    ...result,
    regrouped: existingGroupPairs.length,
    total: items.length,
    date: meta.date,
  };
}

function shouldSkipHistoryRecoverUrl(url) {
  const lower = (url || '').toLowerCase();
  if (
    lower.startsWith('chrome://')
    || lower.startsWith('chrome-extension://')
    || lower.startsWith('edge://')
    || lower.startsWith('about:')
    || lower.startsWith('devtools://')
  ) return true;
  try {
    const host = new URL(url).hostname.toLowerCase();
    if (host === 'chromewebstore.google.com' || host === 'chrome.google.com') return true;
  } catch (_) {
    return true;
  }
  return false;
}

async function getOpenTabUrlKeys() {
  const tabs = await chrome.tabs.query({});
  const keys = new Set();
  for (const tab of tabs) {
    let url = tab.pendingUrl || tab.url || '';
    if (isPlaceholderTabUrl(url) || isSuspendedPlaceholderUrl(url)) {
      const restored = await getPlaceholderRestoreUrl(tab);
      if (restored) url = restored;
    }
    const key = urlKeyForHistory(url);
    if (key) keys.add(key);
  }
  return keys;
}

/**
 * Search chrome.history for URLs not already open (typical "lost" tabs after a crash).
 */
async function searchLostTabsFromHistory({
  hoursBack = 24,
  onlyMissing = true,
  maxResults = 1000,
  text = '',
} = {}) {
  const hours = Math.min(Math.max(Number(hoursBack) || 24, 1), 24 * 30);
  const startTime = Date.now() - hours * 60 * 60 * 1000;
  const openKeys = onlyMissing ? await getOpenTabUrlKeys() : new Set();
  const query = {
    text: typeof text === 'string' ? text.trim() : '',
    startTime,
    maxResults: Math.min(Math.max(Number(maxResults) || 1000, 50), 1000),
  };
  const raw = await chrome.history.search(query);
  const seen = new Set();
  const items = [];
  for (const visit of raw) {
    const url = visit.url;
    if (!hasRestorableUrl(url) || shouldSkipHistoryRecoverUrl(url)) continue;
    const key = urlKeyForHistory(url);
    if (!key || seen.has(key)) continue;
    if (onlyMissing && openKeys.has(key)) continue;
    seen.add(key);
    items.push({
      url,
      title: visit.title || url,
      lastVisitTime: visit.lastVisitTime || 0,
      visitCount: visit.visitCount || 1,
    });
  }
  items.sort((a, b) => b.lastVisitTime - a.lastVisitTime);
  return {
    items: items.slice(0, 500),
    scanned: raw.length,
    hoursBack: hours,
    onlyMissing: !!onlyMissing,
  };
}

/** Recover from browser history as suspended.html placeholders. */
async function runRecoverFromBrowserHistory(options) {
  const { items, scanned } = await searchLostTabsFromHistory(options);
  if (!items.length) {
    return {
      recovered: 0,
      candidates: 0,
      scanned,
      message: 'No matching URLs in history for the selected period (or all are already open).',
    };
  }
  const res = await runOpenUrlsAsPlaceholders(items.map(({ url, title }) => ({ url, title })));
  return {
    recovered: res.opened,
    candidates: items.length,
    scanned,
  };
}

async function persistAlarmBackupEntries(toBackup) {
  if (!toBackup.length) return;
  try {
    const seen = new Set();
    const unique = toBackup.filter((t) => {
      const key = normalizeUrlKey(t.url);
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
    if (!unique.length) return;

    try {
      const folderId = await getOrCreateBackupFolder();
      for (const t of unique) {
        try {
          await chrome.bookmarks.create({
            parentId: folderId,
            title: (t.title || t.url).slice(0, 255),
            url: t.url,
          });
        } catch (e) {
          console.warn('[TabHibernate] backup bookmark failed', e);
        }
      }
    } catch (e) {
      console.warn('[TabHibernate] backup bookmark folder failed', e);
    }

    const backupKey = `backup_${new Date().toISOString().slice(0, 10)}`;
    const existing = await chrome.storage.local.get(backupKey);
    const list = existing[backupKey] || [];
    const existingUrls = new Set(list.map((x) => normalizeUrlKey(x.url)).filter(Boolean));
    for (const t of unique) {
      const key = normalizeUrlKey(t.url);
      if (!key || existingUrls.has(key)) continue;
      list.push({ url: t.url, title: t.title || t.url, ts: Date.now() });
      existingUrls.add(key);
    }
    await persistBoundedList(backupKey, list, BACKUP_ENTRIES_MAX);
  } catch (e) {
    console.warn('[TabHibernate] persistAlarmBackupEntries failed', e);
  }
}

async function getFocusedNormalWindowId() {
  try {
    const window = await chrome.windows.getLastFocused({ windowTypes: ['normal'] });
    return window?.focused && Number.isInteger(window.id) ? window.id : null;
  } catch (_) {
    return null;
  }
}

/** Maintenance must never prevent the inactivity check from running. */
async function runAlarmMaintenance() {
  const now = Date.now();
  const stored = await chrome.storage.local.get(LAST_LIGHT_MAINTENANCE_AT);
  const lastRun = Number(stored[LAST_LIGHT_MAINTENANCE_AT] || 0);
  if (now - lastRun < LIGHT_MAINTENANCE_INTERVAL_MS) return;
  // Persist before the work starts so an interrupted MV3 worker does not
  // repeat the full maintenance scan on its next wake.
  await chrome.storage.local.set({ [LAST_LIGHT_MAINTENANCE_AT]: now });
  const tasks = [
    pruneStaleTabIds,
    pruneChromeGroupKeyRegistry,
    captureDailySessionSnapshot,
    pruneDailySessionSnapshots,
  ];
  for (const task of tasks) {
    try {
      await task();
    } catch (e) {
      console.warn(`[TabHibernate] alarm maintenance ${task.name} failed`, e);
    }
  }
  await runPlaceholderMaintenanceIfDue();
}

/** Main alarm check: suspend inactive tabs and backup if needed. */
async function onAlarmCheck() {
  const startedAt = Date.now();
  try {
    await chrome.storage.local.set({ lastAlarmRun: startedAt });
    await getStoredState();

    const settings = await getSettings();
    await ensureAlarm(settings.checkPeriodMinutes);
    await ensureSiteBlockerAlarm();
    if (!settings.enabled) return;

    const tabs = await chrome.tabs.query({});
    const focusedWindowId = await getFocusedNormalWindowId();
    const groupMeta = await buildGroupMetaMapForTabs(tabs, Date.now());
    if (seedActivityForUnknownTabs(tabs)) await persistLastActivity(true);

    const toBackup = [];
    const suspendedPairs = [];
    let suspendedThisRun = 0;
    for (const tab of tabs) {
      const allowBackgroundActive = SwissCore.shouldAllowActiveTabInAlarm(tab, focusedWindowId);
      if (!(await isTabEligibleForSuspend(tab, { settings, allowActive: allowBackgroundActive }))) continue;
      if (isTabExcludedByDomain(tab, settings.excludedDomains)) continue;
      if (!isTabInactive(tab.id, settings.timeoutMinutes)) continue;
      const mode = getSuspendModeForTab(settings, tab);
      if (mode === 'placeholder' && !hasRestorableUrl(tab.url)) continue;

      if (mode === 'discard') {
        const ok = await suspendDiscard(tab.id, { deferBadge: true });
        if (ok) { toBackup.push({ url: tab.url, title: tab.title }); suspendedThisRun++; }
      } else {
        const ok = await suspendPlaceholder(tab.id, tab.url, tab.title, tab.favIconUrl, {
          groupId: tab.groupId,
          windowId: tab.windowId,
          deferBadge: true,
          ...pickSavedGroupFields(groupMeta.get(tab.id)),
        });
        if (ok) {
          toBackup.push({ url: tab.url, title: tab.title });
          suspendedPairs.push({ tabId: tab.id, item: groupMeta.get(tab.id) });
          suspendedThisRun++;
        }
      }
      if (suspendedThisRun > 0 && suspendedThisRun % 15 === 0) {
        await new Promise((r) => setTimeout(r, SUSPEND_BATCH_DELAY_MS));
      }
    }

    await applySavedTabGroups(suspendedPairs, { forceRegroup: true });
    await updateBadge();
    await persistAlarmBackupEntries(toBackup);
  } catch (e) {
    console.warn('[TabHibernate] onAlarmCheck failed', e);
  } finally {
    await runAlarmMaintenance();
    await chrome.storage.local.set({
      lastAlarmCompletedAt: Date.now(),
      lastAlarmDurationMs: Date.now() - startedAt,
    }).catch(() => {});
  }
}

/** Coalesce alarm events so a slow storage pass cannot start a second check. */
function startAlarmCheck() {
  if (!alarmCheckPromise) {
    alarmCheckPromise = onAlarmCheck().finally(() => {
      alarmCheckPromise = null;
    });
  }
  return alarmCheckPromise;
}

/** Create/update periodic alarm; call on startup and after each check. */
async function ensureAlarm(periodMinutes = ALARM_CHECK_PERIOD_MINUTES) {
  try {
    const period = CHECK_PERIOD_OPTIONS.includes(Number(periodMinutes)) ? Number(periodMinutes) : ALARM_CHECK_PERIOD_MINUTES;
    const existing = await chrome.alarms.get(ALARM_CHECK_NAME);
    if (existing?.periodInMinutes === period) return;
    await chrome.alarms.create(ALARM_CHECK_NAME, { periodInMinutes: period });
  } catch (e) {
    console.warn('[TabHibernate] alarm create', e);
  }
}

/** After browser restart tab.id changes — rebind storage/URL and regroup by groupKey. */
async function rebindPlaceholderStorageKeys() {
  try {
    const tabs = await chrome.tabs.query({});
    const placeholders = tabs.filter(
      (t) => t.url && (isPlaceholderTabUrl(t.url) || isSuspendedPlaceholderUrl(t.url)),
    );
    if (!placeholders.length) return;
    const cursorData = await chrome.storage.local.get(PLACEHOLDER_MAINTENANCE_CURSOR);
    const rawCursor = Number(cursorData[PLACEHOLDER_MAINTENANCE_CURSOR] || 0);
    const cursor = Number.isInteger(rawCursor) && rawCursor >= 0 && rawCursor < placeholders.length
      ? rawCursor
      : 0;
    const batch = placeholders.slice(cursor, cursor + PLACEHOLDER_REBIND_BATCH_MAX);
    const nextCursor = cursor + batch.length >= placeholders.length ? 0 : cursor + batch.length;
    await chrome.storage.local.set({ [PLACEHOLDER_MAINTENANCE_CURSOR]: nextCursor });
    const forGrouping = [];
    for (const tab of batch) {
      try {
        await rebindSinglePlaceholderTab(tab);
      } catch (e) {
        console.warn('[TabHibernate] rebindSinglePlaceholderTab failed', tab.id, e);
      }
      try {
        const fresh = await chrome.tabs.get(tab.id);
        const key = `suspended_${fresh.id}`;
        const data = await chrome.storage.local.get(key);
        const item = data[key];
        if (item?.url) {
          forGrouping.push({ tabId: fresh.id, item });
          continue;
        }
        let urlTabId = null;
        try {
          urlTabId = parseInt(new URL(fresh.url || '').searchParams.get('tabId') || '', 10);
        } catch (_) {}
        const found = await findSuspendedStorageForPlaceholderTab(
          fresh,
          Number.isNaN(urlTabId) ? null : urlTabId,
        );
        if (found?.item?.url) forGrouping.push({ tabId: fresh.id, item: found.item });
      } catch (e) {
        console.warn('[TabHibernate] collect placeholder group data failed', tab.id, e);
      }
    }
    if (forGrouping.length) await applySavedTabGroups(forGrouping, { forceRegroup: true });
    await pruneChromeGroupKeyRegistry();
  } catch (e) {
    console.warn('[TabHibernate] rebindPlaceholderStorageKeys failed', e);
  }
}

/**
 * After an extension reload/update, repair placeholders from an old extension
 * origin and chrome-error tabs whose suspended payload still exists.
 */
async function migrateOrphanedSuspendedTabs({ repairCurrent = false } = {}) {
  try {
    const ourId = chrome.runtime.id;
    const tabs = await chrome.tabs.query({});
    const candidates = [];
    const storageKeys = new Set();
    for (const tab of tabs) {
      if (!tab.id) continue;
      storageKeys.add(`suspended_${tab.id}`);
      const possibleUrls = [tab.pendingUrl, tab.url].filter(Boolean);
      const placeholderUrl = possibleUrls.find(isPlaceholderTabUrl) || '';
      const oldTabId = getPlaceholderUrlTabId(placeholderUrl);
      if (Number.isInteger(oldTabId)) storageKeys.add(`suspended_${oldTabId}`);
      candidates.push({ tab, placeholderUrl, oldTabId });
    }
    const stored = storageKeys.size ? await chrome.storage.local.get([...storageKeys]) : {};
    const repairedGroups = [];
    const indexEntries = [];
    let repaired = 0;

    for (const { tab, placeholderUrl, oldTabId } of candidates) {
      try {
        let item = stored[`suspended_${tab.id}`]
          || (Number.isInteger(oldTabId) ? stored[`suspended_${oldTabId}`] : null);
        let parsedPlaceholder = null;
        if (placeholderUrl) {
          try { parsedPlaceholder = new URL(placeholderUrl); } catch (_) {}
        }
        const fallback = parsedPlaceholder?.searchParams.get('u') || '';
        if (!item?.url && hasRestorableUrl(fallback)) {
          item = { url: fallback, title: tab.title || fallback, favIconUrl: '' };
        }
        if (!item?.url || !hasRestorableUrl(item.url)) continue;

        const isForeignPlaceholder = parsedPlaceholder?.host && parsedPlaceholder.host !== ourId;
        const isCurrentPlaceholder = parsedPlaceholder?.host === ourId;
        const isBrokenError = isChromeBlockedPageUrl(tab.url || '');
        const shouldRepairCurrent = repairCurrent && isCurrentPlaceholder && tab.discarded !== true;
        if (!isForeignPlaceholder && !isBrokenError && !shouldRepairCurrent) continue;

        const rebound = { ...item, tabId: tab.id };
        if (rebound.groupKey) rebound.groupKey = normalizeGroupKey(rebound.groupKey);
        await persistSuspendedPayload(`suspended_${tab.id}`, rebound);
        if (Number.isInteger(oldTabId) && oldTabId !== tab.id) {
          await chrome.storage.local.remove(`suspended_${oldTabId}`);
        }
        const newUrl = new URL(buildSuspendedPlaceholderUrl(tab.id, rebound));
        // A changing repair token forces Chrome to replace a crashed page even
        // when its extension ID and tabId did not change.
        newUrl.searchParams.set('repair', `${chrome.runtime.getManifest().version}-${Date.now()}`);
        await chrome.tabs.update(tab.id, { url: newUrl.toString() });
        repairedGroups.push({ tabId: tab.id, item: rebound });
        indexEntries.push(rebound);
        repaired++;
        if (repaired % PLACEHOLDER_REPAIR_BATCH_SIZE === 0) {
          await new Promise((resolve) => setTimeout(resolve, 80));
        }
      } catch (e) {
        console.warn('[TabHibernate] migrate tab failed', tab.id, e);
      }
    }
    if (indexEntries.length) {
      await mutateSuspendedUrlIndex((idx) => {
        for (const item of indexEntries) {
          const key = normalizeUrlKey(item.url);
          if (key) idx[key] = compactSuspendedUrlIndexEntry({ ...item, updatedAt: Date.now() });
        }
        return true;
      });
    }
    if (repairedGroups.length) await applySavedTabGroups(repairedGroups, { forceRegroup: true });
    return repaired;
  } catch (e) {
    console.warn('[TabHibernate] migrateOrphanedSuspendedTabs failed', e);
    return 0;
  }
}

async function ensureRuntimePlaceholderRepair() {
  if (runtimePlaceholderRepairPromise) return runtimePlaceholderRepairPromise;
  runtimePlaceholderRepairPromise = (async () => {
    const marker = `${chrome.runtime.id}:${chrome.runtime.getManifest().version}`;
    try {
      const session = await chrome.storage.session.get(RUNTIME_PLACEHOLDER_REPAIR_KEY);
      if (session[RUNTIME_PLACEHOLDER_REPAIR_KEY] === marker) return 0;
      await chrome.storage.session.set({ [RUNTIME_PLACEHOLDER_REPAIR_KEY]: marker });
      return await migrateOrphanedSuspendedTabs({ repairCurrent: false });
    } catch (e) {
      console.warn('[TabHibernate] runtime placeholder repair failed', e);
      return 0;
    }
  })();
  return runtimePlaceholderRepairPromise;
}

async function runPlaceholderMaintenance() {
  try {
    await migrateOrphanedSuspendedTabs();
    await recoverBlockerTabsAfterWake();
    await rebindPlaceholderStorageKeys();
  } catch (e) {
    console.warn('[TabHibernate] migrate/rebind placeholders failed', e);
  }
}

async function runPlaceholderMaintenanceIfDue({ force = false } = {}) {
  const now = Date.now();
  const stored = await chrome.storage.local.get(LAST_PLACEHOLDER_MAINTENANCE_AT);
  const lastRun = Number(stored[LAST_PLACEHOLDER_MAINTENANCE_AT] || 0);
  if (!force && now - lastRun < PLACEHOLDER_MAINTENANCE_INTERVAL_MS) return false;
  // Store the timestamp first so a failed/terminated worker does not retry the
  // expensive scan on every subsequent wake.
  await chrome.storage.local.set({ [LAST_PLACEHOLDER_MAINTENANCE_AT]: now });
  await runPlaceholderMaintenance();
  await pruneOldBackups();
  return true;
}

async function initActiveTabsMap() {
  try {
    const focusedWindowId = await getFocusedNormalWindowId();
    lastFocusedWindowId = focusedWindowId;
    const activeTabs = await chrome.tabs.query({ active: true });
    for (const tab of activeTabs) {
      if (tab.id && tab.windowId) {
        lastActiveTabByWindow.set(tab.windowId, tab.id);
        if (tab.windowId === focusedWindowId) markTabActive(tab.id);
      }
    }
  } catch (e) {
    console.warn('[TabHibernate] initActiveTabsMap failed', e);
  }
}

/** Lightweight init on SW wake: alarms + restore activity map. No migrate/rebind or timer reset. */
function ensureServiceWorkerReady() {
  if (!swReadyPromise) {
    swReadyPromise = (async () => {
      const settings = await getSettings();
      await ensureAlarm(settings.checkPeriodMinutes);
      await getStoredState();
      await initActiveTabsMap();
      await updateBadge();
      await ensureSiteBlockerAlarm();
      await ensureBlockerPreserveAlarm();
      if (!placeholderMaintenanceScheduled) {
        placeholderMaintenanceScheduled = true;
        runPlaceholderMaintenanceIfDue().catch((e) => {
          console.warn('[TabHibernate] placeholder maintenance failed', e);
        });
      }
    })().catch((e) => {
      swReadyPromise = null;
      throw e;
    });
  }
  return swReadyPromise;
}

/** Browser/extension lifecycle only — not on every SW wake. */
async function initOnStartup() {
  swReadyPromise = null;
  await ensureServiceWorkerReady();
  // Never wake discarded placeholders just to refresh their favicons. Large
  // restored sessions can otherwise start many renderer processes at once and
  // exhaust Chrome's memory. The favicon bootstrap runs naturally when a user
  // activates a discarded placeholder.
  await compactSuspendedUrlIndex();
  await pruneDuplicateSavedLists();
  await captureDailySessionSnapshot({ reason: 'browser-startup' });
  await pruneDailySessionSnapshots();
}

/** Extension icon click opens the side panel instead of popup. */
async function setSidePanelBehavior() {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (e) {
    console.warn('[TabHibernate] setPanelBehavior failed', e);
  }
}

chrome.runtime.onStartup.addListener(async () => {
  try {
    placeholderMaintenanceScheduled = false;
    await setSidePanelBehavior();
    await initOnStartup();
    await siteBlockerApplyRules({ forceApply: true });
    await siteBlockerApplyAdsRulesets();
  } catch (e) {
    console.error('[SwissExtensions] onStartup failed', e);
  }
});

if (chrome.runtime.onUpdateAvailable) {
  chrome.runtime.onUpdateAvailable.addListener(() => {
    runEmergencySessionBackup('update-available').catch((e) => {
      console.warn('[TabHibernate] pre-update backup failed', e);
    });
  });
}

chrome.runtime.onInstalled.addListener(async (details) => {
  try {
    if (details.reason === 'install') {
      await chrome.storage.local.set({
        settings: {
          enabled: true,
          timeoutMinutes: INACTIVITY_MINUTES,
          checkPeriodMinutes: ALARM_CHECK_PERIOD_MINUTES,
          excludedDomains: [],
          smartRulesEnabled: false,
          smartDefaultMode: 'discard',
          smartUseHeuristicsFallback: true,
          smartPlaceholderDomains: [],
          smartDiscardDomains: [],
          mode: 'placeholder',
          suspendPinnedTabs: true,
          skipGroupedInHibernate: false,
        },
      });
    }
    await setSidePanelBehavior();
    if (details.reason === 'update') {
      await preserveBlockedOpenTabs('extension-update', { convertToPlaceholder: true });
      await runEmergencySessionBackup('extension-update');
      await migrateOrphanedSuspendedTabs();
    }
    await initOnStartup();
    await siteBlockerApplyRules({ forceApply: true });
    await siteBlockerApplyAdsRulesets();
  } catch (e) {
    console.error('[SwissExtensions] onInstalled failed', e);
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === FAVICON_REFRESH_ALARM) {
    processNextSuspendedFaviconRefresh().catch(async (e) => {
      console.warn('[TabHibernate] favicon refresh job failed', e);
      const stored = await chrome.storage.local.get(FAVICON_REFRESH_JOB_KEY).catch(() => ({}));
      const job = stored[FAVICON_REFRESH_JOB_KEY];
      await chrome.storage.local.set({
        [FAVICON_REFRESH_PROGRESS_KEY]: {
          status: 'error',
          done: Number(job?.index) || 0,
          total: Array.isArray(job?.tabIds) ? job.tabIds.length : 0,
          refreshed: Number(job?.refreshed) || 0,
          failed: Number(job?.failed) || 0,
          remaining: Number(job?.remaining) || 0,
          skippedActive: Number(job?.skippedActive) || 0,
          error: String(e?.message || e),
        },
      }).catch(() => {});
      await chrome.storage.local.remove(FAVICON_REFRESH_JOB_KEY).catch(() => {});
    });
    return;
  }
  if (alarm.name.startsWith(RESTORE_ALLOW_RULE_ALARM_PREFIX)) {
    const ruleId = Number(alarm.name.slice(RESTORE_ALLOW_RULE_ALARM_PREFIX.length));
    removeRestoreAllowRule(ruleId).catch(() => {});
    return;
  }
  if (alarm.name === ALARM_CHECK_NAME) startAlarmCheck();
  if (alarm.name === SITE_BLOCKER_SCHEDULE_ALARM) runSiteBlockerApplyRules();
  if (alarm.name === BLOCKER_PRESERVE_ALARM) {
    pruneBlockerTabUrlMap()
      .then(() => preserveBlockedOpenTabs('periodic', { convertToPlaceholder: false }))
      .catch((e) => console.warn('[SiteBlocker] periodic preserve failed', e));
  }
});

chrome.tabs.onActivated.addListener((activeInfo) => {
  const { tabId, windowId } = activeInfo;
  const prevTabId = lastActiveTabByWindow.get(windowId);
  if (prevTabId && prevTabId !== tabId) {
    markTabActive(prevTabId); // Mark previous active tab in this window
  }
  lastActiveTabByWindow.set(windowId, tabId);
  markTabActive(tabId);
  chrome.tabs.get(tabId).then(async (tab) => {
    if (!isPlaceholderTabUrl(tab.url)) return;
    let isCurrentOrigin = false;
    try {
      isCurrentOrigin = new URL(tab.url).host === chrome.runtime.id;
    } catch (_) {}
    if (!isCurrentOrigin) {
      await rebindSinglePlaceholderTab(tab).catch(() => false);
      return;
    }
    // Never reload a healthy current-origin placeholder on activation. Chrome
    // already loads discarded tabs itself; a second reload caused a visible
    // flash every time the user switched to a suspended tab.
  }).catch(() => {});
});

chrome.windows.onFocusChanged.addListener((windowId) => {
  const previousWindowId = lastFocusedWindowId;
  if (Number.isInteger(previousWindowId) && previousWindowId !== windowId) {
    chrome.tabs.query({ active: true, windowId: previousWindowId }).then(([tab]) => {
      if (tab?.id) markTabActive(tab.id);
    }).catch(() => {});
  }
  lastFocusedWindowId = windowId === chrome.windows.WINDOW_ID_NONE ? null : windowId;
  if (lastFocusedWindowId == null) return;
  const focusedWindowId = lastFocusedWindowId;
  chrome.tabs.query({ active: true, windowId: focusedWindowId }).then(([tab]) => {
    if (!tab?.id) return;
    lastActiveTabByWindow.set(focusedWindowId, tab.id);
    markTabActive(tab.id);
  }).catch(() => {});
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (typeof changeInfo.audible === 'boolean') {
    markTabActive(tabId);
  }
  // A busy placeholder may finish its canvas favicon after the page's load
  // event. Retry the safe discard at that point instead of leaving its
  // renderer resident indefinitely.
  if (changeInfo.favIconUrl && isResolvedPlaceholderFavicon(changeInfo.favIconUrl)) {
    chrome.tabs.get(tabId).then((tab) => {
      if (isPlaceholderTabUrl(tab?.url) || isSuspendedPlaceholderUrl(tab?.url)) {
        discardInactivePlaceholder(tab).catch(() => false);
      }
    }).catch(() => {});
  }
  if (changeInfo.url) {
    const navUrl = changeInfo.url;
    if (navUrl.startsWith('http://') || navUrl.startsWith('https://')) {
      rememberTabNavigationUrl(tabId, navUrl);
    }
  }
  if (changeInfo.status === 'complete') {
    chrome.tabs.get(tabId).then(async (tab) => {
      if (!tab?.id) return;
      const url = tab.url || '';
      if (isPlaceholderTabUrl(url) || isSuspendedPlaceholderUrl(url)) {
        await rebindSinglePlaceholderTab(tab).catch(() => false);
        await discardInactivePlaceholder(tab).catch(() => false);
        return;
      }
      if (!isChromeBlockedPageUrl(url)) return;
      const last = lastHttpUrlByTabId.get(tabId);
      if (last && hasRestorableUrl(last)) {
        await rememberBlockerTabUrl(tabId, last, tab.title);
      }
      const domains = await getConfiguredBlockerDomains();
      if (!domains.length) return;
      const pageUrl = await resolveBlockerTabPageUrl(tab);
      if (!pageUrl || !sbUrlMatchesBlockedDomains(pageUrl, domains)) return;
      await convertBlockedTabToPlaceholder(tab, pageUrl);
    }).catch(() => {});
  }
  if (changeInfo.url || changeInfo.status === 'complete') {
    chrome.tabs.get(tabId).then(scheduleSiteBlockerNavEnforce).catch(() => {});
  }
  if (changeInfo.groupId !== undefined) {
    const transitionUntil = placeholderGroupTransitionUntil.get(tabId) || 0;
    if (SwissCore.shouldIgnoreTransientUngroup(changeInfo.groupId, transitionUntil)) return;
    placeholderGroupTransitionUntil.delete(tabId);
    chrome.tabs.get(tabId).then(syncSuspendedStorageGroupMetaForTab).catch(() => {});
  }
});

if (chrome.tabGroups?.onUpdated) {
  chrome.tabGroups.onUpdated.addListener((group) => {
    if (!group?.id) return;
    chrome.tabs.query({ groupId: group.id }).then((tabs) => {
      for (const tab of tabs) syncSuspendedStorageGroupMetaForTab(tab).catch(() => {});
    }).catch(() => {});
  });
}

chrome.tabs.onCreated.addListener((tab) => {
  if (tab.id) markTabActive(tab.id);
});

/** Remember navigation URL before DNR block (onUpdated often misses http). */
function rememberTabNavigationUrl(tabId, url, title = '') {
  if (!tabId || !url || (!url.startsWith('http://') && !url.startsWith('https://'))) return;
  lastHttpUrlByTabId.set(tabId, url);
  getActiveBlockerDomains()
    .then((domains) => {
      if (domains.length && sbUrlMatchesBlockedDomains(url, domains)) {
        return rememberBlockerTabUrl(tabId, url, title);
      }
      return undefined;
    })
    .catch(() => {});
}

if (chrome.webNavigation?.onBeforeNavigate) {
  chrome.webNavigation.onBeforeNavigate.addListener((details) => {
    if (details.frameId !== 0) return;
    rememberTabNavigationUrl(details.tabId, details.url || '');
  });
}

if (chrome.webNavigation?.onCommitted) {
  chrome.webNavigation.onCommitted.addListener((details) => {
    if (!SwissCore.isSuccessfulRestoreCommit(details)) return;
    const key = pendingRestoreKey(details.tabId);
    chrome.storage.local.get(key).then(async (data) => {
      const pending = data[key];
      if (!pending) return;
      const age = Date.now() - Number(pending.createdAt || 0);
      if (!Number.isFinite(age) || age < 0 || age > PENDING_RESTORE_MAX_AGE_MS) {
        await chrome.storage.local.remove(key);
        await removeRestoreAllowRule(pending.allowRuleId);
        return;
      }
      await chrome.storage.local.remove(key);
      await clearRestoredTabData(pending.url, pending.keys || []);
    }).catch((e) => console.warn('[TabHibernate] finalize restore failed', e));
  });
}

if (chrome.webNavigation?.onErrorOccurred) {
  chrome.webNavigation.onErrorOccurred.addListener((details) => {
    if (details.frameId !== 0) return;
    const key = pendingRestoreKey(details.tabId);
    chrome.storage.local.get(key).then(async (data) => {
      await chrome.storage.local.remove(key);
      await removeRestoreAllowRule(data[key]?.allowRuleId);
    }).catch(() => {});

    // DNR's `block` action briefly exposes chrome-error://chromewebdata with
    // the responsible extension's icon. Convert as soon as the main-frame
    // block is reported; onUpdated(status=complete) is only a fallback because
    // Chrome does not consistently emit it for network error pages.
    if (details.error !== 'net::ERR_BLOCKED_BY_CLIENT') return;
    const pageUrl = details.url || '';
    if (!pageUrl.startsWith('http://') && !pageUrl.startsWith('https://')) return;
    getActiveBlockerDomains().then(async (domains) => {
      if (!domains.length || !sbUrlMatchesBlockedDomains(pageUrl, domains)) return;
      await rememberBlockerTabUrl(details.tabId, pageUrl);
      const tab = await chrome.tabs.get(details.tabId).catch(() => null);
      if (!tab?.id) return;
      await convertBlockedTabToPlaceholder(tab, pageUrl);
    }).catch((e) => console.warn('[SiteBlocker] blocked tab placeholder failed', e));
  });
}

function mutateBlockerTabUrlMap(mutator) {
  const operation = blockerTabUrlMutationChain.then(async () => {
    const data = await chrome.storage.local.get(BLOCKER_TAB_URL_KEY);
    const map = { ...(data[BLOCKER_TAB_URL_KEY] || {}) };
    const changed = await mutator(map);
    if (changed === false) return false;
    await chrome.storage.local.set({ [BLOCKER_TAB_URL_KEY]: map });
    return true;
  });
  blockerTabUrlMutationChain = operation.catch((e) => {
    console.warn('[SiteBlocker] tab URL map mutation failed', e);
  });
  return operation;
}

async function flushRemovedTabCleanup() {
  removedTabCleanupTimer = null;
  const tabIds = [...pendingRemovedTabIds];
  const dataTabIds = [...pendingRemovedTabDataIds];
  pendingRemovedTabIds.clear();
  pendingRemovedTabDataIds.clear();
  if (!tabIds.length) return;

  const suspendedKeys = dataTabIds.map((tabId) => `suspended_${tabId}`);
  const restoreKeys = tabIds.map(pendingRestoreKey);
  const stored = await chrome.storage.local.get([
    ...suspendedKeys,
    ...restoreKeys,
    'orphanedSuspendedArchive',
  ]);
  for (const restoreKey of restoreKeys) {
    await removeRestoreAllowRule(stored[restoreKey]?.allowRuleId).catch(() => {});
  }
  const removedItems = dataTabIds
    .map((tabId) => ({ tabId, item: stored[`suspended_${tabId}`] }))
    .filter(({ item }) => item?.url);
  if (removedItems.length) {
    const existingArchive = Array.isArray(stored.orphanedSuspendedArchive)
      ? stored.orphanedSuspendedArchive
      : [];
    const archiveEntries = removedItems.map(({ item }) => ({
      ...item,
      savedAt: Date.now(),
      reason: 'placeholder-tab-removed',
    }));
    // A tab removal can be caused by extension reload/update, not only by the
    // user. Archive first and retain suspendedUrlIndex until an actual web
    // navigation commits successfully.
    await persistBoundedList(
      'orphanedSuspendedArchive',
      [...existingArchive, ...archiveEntries],
      ORPHANED_SUSPENDED_ARCHIVE_MAX,
    );
  }
  await chrome.storage.local.remove([...suspendedKeys, ...restoreKeys]);

  if (dataTabIds.length) {
    const idSet = new Set(dataTabIds.map(String));
    await mutateBlockerTabUrlMap((map) => {
      let changed = false;
      for (const id of idSet) {
        if (map[id] == null) continue;
        delete map[id];
        changed = true;
      }
      return changed;
    });
  }
  scheduleBadgeUpdate();
}

function scheduleRemovedTabCleanup(tabId, { removeTabData = true } = {}) {
  pendingRemovedTabIds.add(tabId);
  if (removeTabData) pendingRemovedTabDataIds.add(tabId);
  if (removedTabCleanupTimer != null) return;
  removedTabCleanupTimer = setTimeout(() => {
    flushRemovedTabCleanup().catch((e) => {
      console.warn('[TabHibernate] removed tab cleanup failed', e);
      scheduleBadgeUpdate();
    });
  }, REMOVED_TAB_CLEANUP_DELAY_MS);
}

/** Не удалять restore-данные при закрытии окна/браузера — иначе после перезагрузки placeholder-вкладки пустые. */
chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  lastActivityByTab.delete(tabId);
  lastHttpUrlByTabId.delete(tabId);
  placeholderGroupTransitionUntil.delete(tabId);
  persistLastActivity();
  for (const [winId, tId] of lastActiveTabByWindow.entries()) {
    if (tId === tabId) {
      lastActiveTabByWindow.delete(winId);
    }
  }
  const windowClosing = removeInfo?.isWindowClosing === true;
  scheduleRemovedTabCleanup(tabId, { removeTabData: !windowClosing });
});

/** Badge updates when closedAndSaved changes (import/clear on History page). */
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && changes.closedAndSaved) scheduleBadgeUpdate();
});

/** Site Blocker: static rulesets + dynamic domain rules (whitelist matches standalone SiteBlocker). */
const SITE_BLOCKER_RULE_ID_START = 10000;
const NETFILTER_RULESET_IDS = ['ruleset_1', 'ruleset_2', 'ruleset_3', 'ruleset_4', 'ruleset_5', 'ruleset_6'];
/** Ads ruleset bundled from standalone Site Blocker extension. */
const SB_ADS_RULESET_IDS = ['sb_siteblocker_ads'];
const SB_DEFAULT_SCHEDULE = {
  enabled: false,
  from: '09:00',
  to: '18:00',
  days: [1, 2, 3, 4, 5],
};

function sbParseHHMM(value) {
  const m = /^(\d{2}):(\d{2})$/.exec(String(value || '').trim());
  if (!m) return null;
  const hh = Number(m[1]);
  const mm = Number(m[2]);
  if (!Number.isInteger(hh) || !Number.isInteger(mm) || hh < 0 || hh > 23 || mm < 0 || mm > 59) return null;
  return hh * 60 + mm;
}

function sbNormalizeSchedule(input) {
  const raw = input && typeof input === 'object' ? input : {};
  const from = typeof raw.from === 'string' ? raw.from : SB_DEFAULT_SCHEDULE.from;
  const to = typeof raw.to === 'string' ? raw.to : SB_DEFAULT_SCHEDULE.to;
  const days = Array.isArray(raw.days)
    ? raw.days.map((d) => Number(d)).filter((d) => Number.isInteger(d) && d >= 0 && d <= 6)
    : SB_DEFAULT_SCHEDULE.days.slice();
  return {
    enabled: raw.enabled === true,
    from: sbParseHHMM(from) != null ? from : SB_DEFAULT_SCHEDULE.from,
    to: sbParseHHMM(to) != null ? to : SB_DEFAULT_SCHEDULE.to,
    days: [...new Set(days)],
  };
}

function sbIsInSchedule(schedule, now = new Date()) {
  if (!schedule.enabled) return true;
  if (!schedule.days.includes(now.getDay())) return false;
  const from = sbParseHHMM(schedule.from);
  const to = sbParseHHMM(schedule.to);
  if (from == null || to == null) return false;
  const nowMin = now.getHours() * 60 + now.getMinutes();
  if (from === to) return true;
  if (from < to) return nowMin >= from && nowMin < to;
  return nowMin >= from || nowMin < to;
}

function sbNormDomain(d) {
  let s = (d || '').trim().toLowerCase();
  if (!s) return '';
  try { if (!s.startsWith('http')) s = 'https://' + s; return new URL(s).hostname.replace(/^www\./, '') || ''; } catch { return s.replace(/^www\./, '').split('/')[0].split('?')[0]; }
}

function sbHostMatchesDomains(hostname, domains) {
  if (!hostname || !Array.isArray(domains) || domains.length === 0) return false;
  const host = hostname.replace(/^www\./, '').toLowerCase();
  return domains.some((domain) => host === domain || host.endsWith(`.${domain}`));
}

function sbUrlMatchesBlockedDomains(url, domains) {
  try {
    const parsed = new URL(url || '');
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false;
    return sbHostMatchesDomains(parsed.hostname, domains);
  } catch (_) {
    return false;
  }
}

const BLOCKED_TABS_SAVED_MAX = 5000;

async function getOrCreateSiteBlockerSavedFolder() {
  const tree = await chrome.bookmarks.getTree();
  const root = tree[0];
  let parent = findBookmarkFolder(root.children, 'Site Blocker');
  if (!parent) {
    const writableParent = getWritableBookmarkParent(root);
    if (!writableParent?.id) throw new Error('No writable bookmarks folder');
    const created = await chrome.bookmarks.create({ parentId: writableParent.id, title: 'Site Blocker' });
    parent = { id: created.id };
  }
  let folder = findBookmarkFolder([parent], 'Saved tabs');
  if (folder?.id) return folder.id;
  const created = await chrome.bookmarks.create({ parentId: parent.id, title: 'Saved tabs' });
  return created.id;
}

/** Local Site Blocker history + user bookmarks (chrome.storage + bookmarks). */
async function appendBlockedTabsSaved(entries, { reason = 'block', writeBookmarks = true } = {}) {
  if (!entries?.length) return { added: 0 };
  const { blockedTabsSaved = [] } = await chrome.storage.local.get('blockedTabsSaved');
  const seen = new Set(blockedTabsSaved.map((x) => normalizeUrlKey(x.url)).filter(Boolean));
  const merged = blockedTabsSaved.slice();
  const newlyAdded = [];
  for (const entry of entries) {
    const key = normalizeUrlKey(entry?.url);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    merged.push({
      url: entry.url,
      title: entry.title || entry.url,
      domain: entry.domain || '',
      savedAt: Date.now(),
      reason: reason || 'block',
      ...pickSavedGroupFields(entry),
    });
    newlyAdded.push(entry);
  }
  if (!newlyAdded.length) return { added: 0 };
  await chrome.storage.local.set({ blockedTabsSaved: merged.slice(-BLOCKED_TABS_SAVED_MAX) });
  if (writeBookmarks) {
    try {
      const folderId = await getOrCreateSiteBlockerSavedFolder();
      for (const entry of newlyAdded) {
        try {
          await chrome.bookmarks.create({
            parentId: folderId,
            title: (entry.title || entry.url).slice(0, 255),
            url: entry.url,
          });
        } catch (e) {
          console.warn('[SiteBlocker] bookmark save failed', entry.url, e);
        }
      }
    } catch (e) {
      console.warn('[SiteBlocker] saved tabs folder failed', e);
    }
  }
  return { added: newlyAdded.length };
}

async function collectOpenTabsOnBlockedDomains(domains) {
  if (!domains?.length) return [];
  const tabs = await chrome.tabs.query({});
  const matchingTabs = [];
  for (const tab of tabs) {
    let url = tab.pendingUrl || tab.url || '';
    if (isPlaceholderTabUrl(url) || isSuspendedPlaceholderUrl(url)) {
      const restored = await getPlaceholderRestoreUrl(tab);
      if (restored) url = restored;
    }
    if (!hasRestorableUrl(url) || !sbUrlMatchesBlockedDomains(url, domains)) continue;
    matchingTabs.push({ tab, url });
  }
  const batchId = Date.now();
  const groupMeta = await buildGroupMetaMapForTabs(matchingTabs.map((m) => m.tab), batchId);
  const entries = [];
  const seen = new Set();
  for (const { tab, url } of matchingTabs) {
    const key = normalizeUrlKey(url);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    let domain = '';
    try {
      domain = sbNormDomain(new URL(url).hostname);
    } catch (_) {}
    let entry = { url, title: tab.title || url, domain };
    entry = copyGroupMetaToEntry(entry, groupMeta.get(tab.id));
    entries.push(entry);
  }
  return entries;
}

async function saveOpenTabsMatchingBlockedDomains(domains, reason) {
  const entries = await collectOpenTabsOnBlockedDomains(domains);
  return appendBlockedTabsSaved(entries, { reason, writeBookmarks: true });
}

async function maybeAutoSaveBlockedTabs(domains, reason) {
  const { blockerAutoSaveTabs = true } = await chrome.storage.local.get('blockerAutoSaveTabs');
  if (blockerAutoSaveTabs === false || !domains?.length) return { added: 0 };
  return saveOpenTabsMatchingBlockedDomains(domains, reason);
}

function isChromeBlockedPageUrl(url) {
  return Boolean(
    url && (url.startsWith('chrome-error://') || url.startsWith('chrome://network-error/'))
  );
}

async function convertBlockedTabToPlaceholder(tab, pageUrl) {
  if (!tab?.id || !pageUrl || blockerPlaceholderConversions.has(tab.id)) return false;
  if (isPlaceholderTabUrl(tab.url) || isSuspendedPlaceholderUrl(tab.url)) return true;
  blockerPlaceholderConversions.add(tab.id);
  try {
    return await suspendPlaceholder(tab.id, pageUrl, tab.title || pageUrl, '', {
      groupId: tab.groupId,
      windowId: tab.windowId,
      skipBookmark: true,
      // The placeholder resolves the favicon by original URL. A chrome-error
      // tab only exposes the extension icon, so it must never be persisted.
      skipFavicon: true,
    });
  } finally {
    blockerPlaceholderConversions.delete(tab.id);
  }
}

async function getConfiguredBlockerDomains() {
  const { blocked = [], whitelist = [] } = await chrome.storage.local.get(['blocked', 'whitelist']);
  const whitelistSet = new Set((whitelist || []).map(sbNormDomain).filter(Boolean));
  const seen = new Set();
  return (blocked || []).map(sbNormDomain).filter(Boolean).filter((d) => {
    if (seen.has(d) || whitelistSet.has(d)) return false;
    seen.add(d);
    return true;
  });
}

async function rememberBlockerTabUrl(tabId, url, title = '') {
  if (!tabId || !hasRestorableUrl(url)) return;
  await mutateBlockerTabUrlMap((map) => {
    map[String(tabId)] = { url, title: title || url, at: Date.now() };
    return true;
  });
}

/** Page URL before chrome-error or after extension disable. */
async function resolveBlockerTabPageUrl(tab) {
  if (!tab?.id) return '';
  let url = tab.pendingUrl || tab.url || '';
  if (isPlaceholderTabUrl(url) || isSuspendedPlaceholderUrl(url)) {
    url = (await getPlaceholderRestoreUrl(tab)) || url;
  }
  if (hasRestorableUrl(url) && !isChromeBlockedPageUrl(url)) return url;
  const remembered = await chrome.storage.local.get(BLOCKER_TAB_URL_KEY);
  const entry = remembered[BLOCKER_TAB_URL_KEY]?.[String(tab.id)];
  if (entry?.url && hasRestorableUrl(entry.url)) return entry.url;
  const lastNav = lastHttpUrlByTabId.get(tab.id);
  if (lastNav && hasRestorableUrl(lastNav) && !isChromeBlockedPageUrl(lastNav)) return lastNav;
  return '';
}

async function tabMatchesBlockerPreserve(tab, domains) {
  if (!tab?.id || !domains?.length) return false;
  const liveUrl = tab.url || '';
  if (isPlaceholderTabUrl(liveUrl) || isSuspendedPlaceholderUrl(liveUrl)) return false;
  if (isChromeBlockedPageUrl(liveUrl)) return true;
  const pageUrl = await resolveBlockerTabPageUrl(tab);
  return pageUrl && sbUrlMatchesBlockedDomains(pageUrl, domains);
}

/**
 * Persist tabs on blocked sites to History/bookmarks;
 * with convertToPlaceholder, move to suspended.html so URL survives disable.
 */
async function preserveBlockedOpenTabs(reason = 'preserve', { convertToPlaceholder = true } = {}) {
  const domains = await getConfiguredBlockerDomains();
  if (!domains.length) return { saved: 0, converted: 0 };

  const tabs = await chrome.tabs.query({});
  const groupMeta = await buildGroupMetaMapForTabs(tabs, Date.now());
  const entries = [];
  const suspendedPairs = [];
  let converted = 0;

  for (const tab of tabs) {
    if (!tab?.id) continue;
    if (!(await tabMatchesBlockerPreserve(tab, domains))) continue;

    const url = await resolveBlockerTabPageUrl(tab);
    if (!url) continue;

    let domain = '';
    try {
      domain = sbNormDomain(new URL(url).hostname);
    } catch (_) {}

    let entry = { url, title: tab.title || url, domain };
    entry = copyGroupMetaToEntry(entry, groupMeta.get(tab.id));
    entries.push(entry);

    if (convertToPlaceholder && !isPlaceholderTabUrl(tab.url) && !isSuspendedPlaceholderUrl(tab.url)) {
      const ok = await suspendPlaceholder(tab.id, url, tab.title, tab.favIconUrl, {
        groupId: tab.groupId,
        windowId: tab.windowId,
        deferBadge: true,
        ...pickSavedGroupFields(groupMeta.get(tab.id)),
      });
      if (ok) {
        suspendedPairs.push({ tabId: tab.id, item: groupMeta.get(tab.id) });
        converted++;
      }
    }
  }

  await applySavedTabGroups(suspendedPairs, { forceRegroup: true });
  if (converted) await updateBadge();

  const saveRes = entries.length
    ? await appendBlockedTabsSaved(entries, { reason, writeBookmarks: true })
    : { added: 0 };

  return { saved: saveRes.added || 0, converted, candidates: entries.length };
}

/** After disable/re-enable: chrome-error → placeholder with saved URL. */
async function recoverBlockerTabsAfterWake() {
  const domains = await getConfiguredBlockerDomains();
  if (!domains.length) return { converted: 0 };

  const tabs = await chrome.tabs.query({});
  const groupMeta = await buildGroupMetaMapForTabs(tabs, Date.now());
  const suspendedPairs = [];
  let converted = 0;
  for (const tab of tabs) {
    if (!tab?.id) continue;
    const liveUrl = tab.url || '';
    if (isPlaceholderTabUrl(liveUrl) || isSuspendedPlaceholderUrl(liveUrl)) continue;
    if (!isChromeBlockedPageUrl(liveUrl)) continue;
    const url = await resolveBlockerTabPageUrl(tab);
    if (!url || !sbUrlMatchesBlockedDomains(url, domains)) continue;
    const ok = await suspendPlaceholder(tab.id, url, tab.title, tab.favIconUrl, {
      groupId: tab.groupId,
      windowId: tab.windowId,
      deferBadge: true,
      ...pickSavedGroupFields(groupMeta.get(tab.id)),
    });
    if (ok) {
      suspendedPairs.push({ tabId: tab.id, item: groupMeta.get(tab.id) });
      converted++;
    }
  }
  await applySavedTabGroups(suspendedPairs, { forceRegroup: true });
  if (converted) await updateBadge();
  return { converted };
}

async function ensureBlockerPreserveAlarm() {
  try {
    const existing = await chrome.alarms.get(BLOCKER_PRESERVE_ALARM);
    if (existing) return;
    await chrome.alarms.create(BLOCKER_PRESERVE_ALARM, { periodInMinutes: BLOCKER_PRESERVE_PERIOD_MINUTES });
  } catch (e) {
    console.warn('[SiteBlocker] ensureBlockerPreserveAlarm failed', e);
  }
}

async function pruneBlockerTabUrlMap() {
  try {
    const tabs = await chrome.tabs.query({});
    const ids = new Set(tabs.map((t) => String(t.id)));
    await mutateBlockerTabUrlMap((map) => {
      let changed = false;
      for (const k of Object.keys(map)) {
        if (!ids.has(k)) {
          delete map[k];
          changed = true;
        }
      }
      return changed;
    });
  } catch (e) {
    console.warn('[SiteBlocker] pruneBlockerTabUrlMap failed', e);
  }
}
async function getActiveBlockerDomains() {
  const { blocked = [], whitelist = [], enabled, schedule } = await chrome.storage.local.get([
    'blocked',
    'whitelist',
    'enabled',
    'schedule',
  ]);
  if (enabled === false) return [];
  if (!sbIsInSchedule(sbNormalizeSchedule(schedule))) return [];
  const whitelistSet = new Set((whitelist || []).map(sbNormDomain).filter(Boolean));
  const seen = new Set();
  return (blocked || []).map(sbNormDomain).filter(Boolean).filter((d) => {
    if (seen.has(d) || whitelistSet.has(d)) return false;
    seen.add(d);
    return true;
  });
}

/**
 * A restore click is an explicit user request to open this site. If Site
 * Blocker still covers the URL, whitelist the matching configured domain and
 * wait until the DNR rules are rebuilt before navigating the tab.
 */
async function unblockSiteForRestore(url, tabId) {
  // A high-priority, tab-scoped session rule guarantees that this explicit
  // restore click wins even while dynamic blocker rules are being rebuilt.
  const allowRuleId = await installRestoreAllowRule(tabId, url);
  if (!url || !sbUrlMatchesBlockedDomains(url, await getActiveBlockerDomains())) {
    return { unblocked: false, domain: '', allowRuleId };
  }

  let hostname = '';
  try {
    hostname = new URL(url).hostname.replace(/^www\./i, '').toLowerCase();
  } catch (_) {
    await removeRestoreAllowRule(allowRuleId);
    return { unblocked: false, domain: '', allowRuleId: null };
  }

  const { blocked = [], whitelist = [] } = await chrome.storage.local.get(['blocked', 'whitelist']);
  const configuredDomains = blocked.map(sbNormDomain).filter(Boolean);
  const matchedDomain = configuredDomains.find(
    (domain) => hostname === domain || hostname.endsWith(`.${domain}`),
  );
  if (!matchedDomain) return { unblocked: false, domain: '', allowRuleId };

  const normalizedWhitelist = whitelist.map(sbNormDomain).filter(Boolean);
  if (!normalizedWhitelist.includes(matchedDomain)) {
    await chrome.storage.local.set({ whitelist: [...whitelist, matchedDomain] });
  }
  await siteBlockerApplyRules({ enforceOpenTabs: false });
  return { unblocked: true, domain: matchedDomain, allowRuleId };
}

async function siteBlockerReloadBlockedOpenTabs(domains) {
  if (!domains?.length) return;
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (!tab?.id) continue;
    const url = tab.url || '';
    if (isPlaceholderTabUrl(url) || isSuspendedPlaceholderUrl(url)) continue;
    if (isChromeBlockedPageUrl(url)) continue;
    if (!sbUrlMatchesBlockedDomains(url, domains)) continue;
    await rememberBlockerTabUrl(tab.id, url, tab.title);
    try {
      await chrome.tabs.reload(tab.id, { bypassCache: true });
    } catch (e) {
      console.warn('[SiteBlocker] reload blocked tab failed', tab.id, e);
    }
  }
}

function scheduleSiteBlockerNavEnforce(tab) {
  if (!tab?.id) return;
  siteBlockerNavEnforceChain = siteBlockerNavEnforceChain
    .then(() => maybeReloadTabIfBlocked(tab))
    .catch(() => {});
}

/** Reload tabs already open on a blocked domain (e.g. after Back) under DNR. */
async function maybeReloadTabIfBlocked(tab) {
  if (!tab?.id) return;
  const url = tab.url || '';
  if (isPlaceholderTabUrl(url) || isSuspendedPlaceholderUrl(url)) return;
  if (isChromeBlockedPageUrl(url)) return;
  if (!url.startsWith('http://') && !url.startsWith('https://')) return;
  const domains = await getActiveBlockerDomains();
  if (!domains.length || !sbUrlMatchesBlockedDomains(url, domains)) return;
  await rememberBlockerTabUrl(tab.id, url, tab.title);
  try {
    await chrome.tabs.reload(tab.id, { bypassCache: true });
  } catch (e) {
    console.warn('[SiteBlocker] enforce navigation block failed', tab.id, e);
  }
}

/** Recreate schedule alarm if Chrome dropped it (restart / update). */
async function ensureSiteBlockerAlarm() {
  try {
    const existing = await chrome.alarms.get(SITE_BLOCKER_SCHEDULE_ALARM);
    if (existing) return;
    await chrome.alarms.create(SITE_BLOCKER_SCHEDULE_ALARM, { periodInMinutes: SITE_BLOCKER_SCHEDULE_PERIOD_MINUTES });
  } catch (e) {
    console.warn('[SiteBlocker] ensureSiteBlockerAlarm failed', e);
  }
}

function runSiteBlockerApplyRules(options) {
  siteBlockerApplyChain = siteBlockerApplyChain
    .then(() => siteBlockerApplyRulesImpl(options))
    .catch((e) => console.warn('[SiteBlocker] applyRules failed', e));
  return siteBlockerApplyChain;
}

async function siteBlockerApplyAdsRulesets() {
  const { adsFiltersEnabled = true } = await chrome.storage.local.get('adsFiltersEnabled');
  const on = adsFiltersEnabled !== false;
  try {
    if (on) {
      await chrome.declarativeNetRequest.updateEnabledRulesets({
        enableRulesetIds: SB_ADS_RULESET_IDS,
        disableRulesetIds: [],
      });
    } else {
      await chrome.declarativeNetRequest.updateEnabledRulesets({
        enableRulesetIds: [],
        disableRulesetIds: SB_ADS_RULESET_IDS,
      });
    }
  } catch (e) {
    console.warn('[SiteBlocker] ads rulesets failed', e);
  }
}

async function siteBlockerApplyRules(options) {
  return runSiteBlockerApplyRules(options);
}

async function siteBlockerApplyRulesImpl({ enforceOpenTabs = false, forceApply = false } = {}) {
  const {
    blocked = [],
    whitelist = [],
    enabled = true,
    schedule = SB_DEFAULT_SCHEDULE,
    scheduleStateActive: previousScheduleStateActive,
    [SITE_BLOCKER_RULE_SIGNATURE_KEY]: previousRuleSignature = '',
    [BLOCKER_OPEN_TAB_ENFORCE_AT_KEY]: previousOpenTabEnforceAt = 0,
  } = await chrome.storage.local.get([
    'blocked',
    'whitelist',
    'enabled',
    'schedule',
    'scheduleStateActive',
    SITE_BLOCKER_RULE_SIGNATURE_KEY,
    BLOCKER_OPEN_TAB_ENFORCE_AT_KEY,
  ]);

  const normalizedSchedule = sbNormalizeSchedule(schedule);
  const scheduleActive = sbIsInSchedule(normalizedSchedule);
  const blockingWindowActive = enabled !== false && scheduleActive;
  const whitelistSet = new Set((whitelist || []).map(sbNormDomain).filter(Boolean));
  const seen = new Set();
  const domains = blocked.map(sbNormDomain).filter(Boolean).filter((d) => {
    if (seen.has(d) || whitelistSet.has(d)) return false;
    seen.add(d);
    return true;
  });
  const ruleSignature = JSON.stringify({ active: blockingWindowActive, domains });

  const statePatch = {};
  if (previousScheduleStateActive !== scheduleActive) statePatch.scheduleStateActive = scheduleActive;
  if (JSON.stringify(schedule) !== JSON.stringify(normalizedSchedule)) statePatch.schedule = normalizedSchedule;
  if (Object.keys(statePatch).length) await chrome.storage.local.set(statePatch);

  if (!forceApply && !enforceOpenTabs && previousRuleSignature === ruleSignature) {
    const shouldPeriodicReload = blockingWindowActive
      && domains.length > 0
      && (Date.now() - Number(previousOpenTabEnforceAt || 0) >= BLOCKER_OPEN_TAB_ENFORCE_MS);
    if (shouldPeriodicReload) {
      await chrome.storage.local.set({ [BLOCKER_OPEN_TAB_ENFORCE_AT_KEY]: Date.now() });
      await siteBlockerReloadBlockedOpenTabs(domains);
    }
    return;
  }

  let existing;
  try {
    existing = await chrome.declarativeNetRequest.getDynamicRules();
  } catch (e) {
    console.warn('[SiteBlocker] getDynamicRules failed', e);
    return;
  }
  const toRemove = existing.map((r) => r.id).filter((id) => id >= SITE_BLOCKER_RULE_ID_START);

  if (!blockingWindowActive) {
    // Disabling the blocker or leaving its schedule must not navigate the
    // user's open pages. Preserve recovery metadata without hibernating tabs.
    await preserveBlockedOpenTabs('blocking-off', { convertToPlaceholder: false });
    try {
      await chrome.declarativeNetRequest.updateEnabledRulesets({ disableRulesetIds: NETFILTER_RULESET_IDS });
    } catch (e) {
      console.warn('[SiteBlocker] disable NetFilter rulesets failed', e);
    }
    if (toRemove.length) {
      try {
        await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: toRemove });
      } catch (e) {
        console.warn('[SiteBlocker] remove dynamic rules failed', e);
      }
    }
    await chrome.storage.local.set({
      lastBlockerApplyAt: Date.now(),
      lastBlockerApplyOk: true,
      blockerRuleCount: 0,
      [SITE_BLOCKER_RULE_SIGNATURE_KEY]: ruleSignature,
    });
    return;
  }

  try {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: NETFILTER_RULESET_IDS });
  } catch (e) {
    console.warn('[SiteBlocker] enable NetFilter rulesets failed', e);
  }

  if (!blocked.length) {
    if (toRemove.length) {
      try {
        await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: toRemove });
      } catch (e) {
        console.warn('[SiteBlocker] clear dynamic rules failed', e);
      }
    }
    await chrome.storage.local.set({
      lastBlockerApplyAt: Date.now(),
      lastBlockerApplyOk: true,
      blockerRuleCount: 0,
      [SITE_BLOCKER_RULE_SIGNATURE_KEY]: ruleSignature,
    });
    return;
  }

  if (!domains.length) {
    if (toRemove.length) {
      try {
        await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: toRemove });
      } catch (e) {
        console.warn('[SiteBlocker] clear dynamic rules (empty domains) failed', e);
      }
    }
    await chrome.storage.local.set({
      lastBlockerApplyAt: Date.now(),
      lastBlockerApplyOk: true,
      blockerRuleCount: 0,
      [SITE_BLOCKER_RULE_SIGNATURE_KEY]: ruleSignature,
    });
    return;
  }

  const rules = domains.flatMap((d, i) => ([
    {
      id: SITE_BLOCKER_RULE_ID_START + i * 2,
      priority: 1,
      action: { type: 'block' },
      condition: {
        urlFilter: `*://${d}/*`,
        resourceTypes: ['main_frame', 'sub_frame'],
      },
    },
    {
      id: SITE_BLOCKER_RULE_ID_START + i * 2 + 1,
      priority: 1,
      action: { type: 'block' },
      condition: {
        urlFilter: `*://*.${d}/*`,
        resourceTypes: ['main_frame', 'sub_frame'],
      },
    },
  ]));

  try {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: toRemove, addRules: rules });
    await chrome.storage.local.set({
      lastBlockerApplyAt: Date.now(),
      lastBlockerApplyOk: true,
      blockerRuleCount: rules.length,
      [SITE_BLOCKER_RULE_SIGNATURE_KEY]: ruleSignature,
    });
  } catch (e) {
    console.warn('[SiteBlocker] updateDynamicRules failed', e);
    await chrome.storage.local.set({
      lastBlockerApplyAt: Date.now(),
      lastBlockerApplyOk: false,
      lastBlockerApplyError: (e && e.message) || String(e),
    });
    return;
  }

  const shouldSaveBlockedTabs = enforceOpenTabs
    || (previousScheduleStateActive === false && scheduleActive);
  if (shouldSaveBlockedTabs) {
    await maybeAutoSaveBlockedTabs(domains, enforceOpenTabs ? 'block-list-change' : 'schedule-on');
  }

  const shouldReloadOpenTabs = enforceOpenTabs
    || (previousScheduleStateActive === false && blockingWindowActive);
  const shouldPeriodicReload = !shouldReloadOpenTabs
    && blockingWindowActive
    && domains.length > 0
    && (Date.now() - Number(previousOpenTabEnforceAt || 0) >= BLOCKER_OPEN_TAB_ENFORCE_MS);
  if (shouldReloadOpenTabs || shouldPeriodicReload) {
    if (shouldReloadOpenTabs) {
      await maybeAutoSaveBlockedTabs(domains, 'before-reload');
    }
    await chrome.storage.local.set({ [BLOCKER_OPEN_TAB_ENFORCE_AT_KEY]: Date.now() });
    await siteBlockerReloadBlockedOpenTabs(domains);
  }
}

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local') return;
  if (changes.adsFiltersEnabled) siteBlockerApplyAdsRulesets();
  if (changes.blocked || changes.whitelist || changes.enabled || changes.schedule) {
    runSiteBlockerApplyRules({ enforceOpenTabs: true });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const safeSend = (value) => {
    try {
      sendResponse(value);
    } catch (e) {
      console.warn('[TabHibernate] sendResponse failed', e);
    }
  };
  if (msg.type === 'activity') {
    const tabId = sender.tab?.id;
    if (tabId) markTabActive(tabId);
    safeSend({ ok: true });
    return true;
  }
  if (msg.type === 'rebindPlaceholderTab') {
    const tab = sender.tab;
    if (!tab?.id) {
      safeSend({ ok: false });
      return true;
    }
    rebindSinglePlaceholderTab(tab)
      .then((ok) => safeSend({ ok }))
      .catch(() => safeSend({ ok: false }));
    return true;
  }
  if (msg.type === 'resolvePlaceholderData') {
    const tab = sender.tab;
    if (!tab?.id) {
      safeSend(null);
      return true;
    }
    (async () => {
      await rebindSinglePlaceholderTab(tab).catch(() => {});
      let urlTabId = null;
      try {
        urlTabId = parseInt(new URL(tab.url || '').searchParams.get('tabId') || '', 10);
      } catch (_) {}
      const found = await findSuspendedStorageForPlaceholderTab(
        tab,
        Number.isNaN(urlTabId) ? null : urlTabId,
      );
      safeSend(found?.item || null);
    })().catch(() => safeSend(null));
    return true;
  }
  if (msg.type === 'restoreSuspendedTab') {
    const currentTabId = sender.tab?.id || (Number.isInteger(msg.tabId) ? msg.tabId : null);
    const storedTabId = Number.isInteger(msg.tabId) ? msg.tabId : null;
    const url = typeof msg.url === 'string' ? msg.url : '';
    if (!currentTabId || !hasRestorableUrl(url)) {
      safeSend({ ok: false, error: 'Restore data unavailable' });
      return true;
    }
    (async () => {
      let responded = false;
      let allowRuleId = null;
      try {
        const currentTab = await chrome.tabs.get(currentTabId);
        const found = await findSuspendedStorageForPlaceholderTab(currentTab, storedTabId);
        const unblockResult = await unblockSiteForRestore(url, currentTabId);
        allowRuleId = unblockResult.allowRuleId;
        const keys = SwissCore.getRestoreStorageKeys(currentTabId, storedTabId, found?.oldKey);
        await chrome.storage.local.set({
          [pendingRestoreKey(currentTabId)]: {
            url,
            keys,
            allowRuleId: unblockResult.allowRuleId,
            createdAt: Date.now(),
          },
        });

        // The placeholder performs location.replace only after receiving this
        // response. Cleanup happens from webNavigation.onCommitted, so failed
        // navigation keeps the recovery entry intact.
        safeSend({
          ok: true,
          navigateUrl: url,
          unblocked: unblockResult.unblocked,
          domain: unblockResult.domain,
        });
        responded = true;
      } catch (e) {
        if (!responded) await removeRestoreAllowRule(allowRuleId);
        if (!responded) safeSend({ ok: false, error: String(e?.message || e) });
        else console.warn('[TabHibernate] restore preparation failed', e);
      }
    })();
    return true;
  }
  if (msg.type === 'getRestoreData') {
    const tabId = msg.tabId;
    chrome.storage.local.get(`suspended_${tabId}`).then((data) => {
      const key = `suspended_${tabId}`;
      safeSend(data[key] || null);
    }).catch((e) => {
      console.warn('[TabHibernate] getRestoreData failed', e);
      safeSend(null);
    });
    return true;
  }
  if (msg.type === 'dedupeSavedHistory') {
    pruneDuplicateSavedLists()
      .then((result) => safeSend({ ok: !result.error, ...result }))
      .catch((e) => safeSend({ ok: false, removed: 0, error: String(e?.message || e) }));
    return true;
  }
  if (msg.type === 'backupNow') {
    runBackup('manual').then((res) => safeSend(res)).catch((e) => {
      console.warn('[TabHibernate] backupNow failed', e);
      safeSend({ count: 0, error: String(e.message) });
    });
    return true;
  }
  if (msg.type === 'getDailySessionSnapshots') {
    (async () => {
      const stored = await chrome.storage.local.get(DAILY_SESSION_SNAPSHOT_CATALOG);
      const snapshots = normalizeDailySnapshotCatalog(stored[DAILY_SESSION_SNAPSHOT_CATALOG])
        .sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
      safeSend({ snapshots, retentionDays: BACKUP_RETENTION_DAYS });
    })().catch((e) => safeSend({ snapshots: [], error: String(e?.message || e) }));
    return true;
  }
  if (msg.type === 'captureDailySessionSnapshot') {
    captureDailySessionSnapshot({ reason: 'manual' })
      .then((result) => safeSend(result))
      .catch((e) => safeSend({ created: false, error: String(e?.message || e) }));
    return true;
  }
  if (msg.type === 'restoreDailySessionSnapshot') {
    runRestoreDailySessionSnapshot(String(msg.storageKey || ''))
      .then((result) => safeSend(result))
      .catch((e) => safeSend({ opened: 0, regrouped: 0, error: String(e?.message || e) }));
    return true;
  }
  if (msg.type === 'getStats') {
    chrome.storage.local.get(['suspendedToday', 'suspendedTodayDate']).then((data) => {
      const today = new Date().toISOString().slice(0, 10);
      const count = data.suspendedTodayDate === today ? (data.suspendedToday || 0) : 0;
      safeSend({ suspendedToday: count });
    }).catch((e) => {
      console.warn('[TabHibernate] getStats failed', e);
      safeSend({ suspendedToday: 0 });
    });
    return true;
  }
  if (msg.type === 'getStatus') {
    Promise.all([
      chrome.storage.local.get(['suspendedToday', 'suspendedTodayDate', 'lastAlarmRun']),
      getEligibleTabsForBackup(),
      getHibernatedCount(),
    ]).then(async ([data, eligibleTabs, hibernatedCount]) => {
      const today = new Date().toISOString().slice(0, 10);
      const suspendedToday = data.suspendedTodayDate === today ? (data.suspendedToday || 0) : 0;
      await updateBadge(hibernatedCount);
      safeSend({
        suspendedToday,
        hibernatedCount,
        lastAlarmRun: data.lastAlarmRun || 0,
        eligibleTabCount: eligibleTabs.length,
        closedSavedMax: CLOSED_SAVED_MAX,
      });
    }).catch((e) => {
      console.warn('[TabHibernate] getStatus failed', e);
      safeSend({ suspendedToday: 0, hibernatedCount: 0, lastAlarmRun: 0, eligibleTabCount: 0, closedSavedMax: CLOSED_SAVED_MAX });
    });
    return true;
  }
  if (msg.type === 'getConstants') {
    safeSend({ closedSavedMax: CLOSED_SAVED_MAX });
    return true;
  }
  if (msg.type === 'clearRestoreData') {
    if (msg.tabId) chrome.storage.local.remove(`suspended_${msg.tabId}`);
    safeSend({ ok: true });
    return true;
  }
  if (msg.type === 'settingsUpdated') {
    getSettings()
      .then((s) => ensureAlarm(s.checkPeriodMinutes))
      .then(() => safeSend({ ok: true }))
      .catch(() => safeSend({ ok: false }));
    return true;
  }
  if (msg.type === 'refreshSuspendedFavicons') {
    (async () => {
      try {
        const result = await startSuspendedFaviconRefresh();
        // Close the message channel before the first tab is loaded. The job is
        // already persisted and has an alarm fallback at this point.
        safeSend(result);
        if (result.started && !result.alreadyRunning) {
          try {
            await processNextSuspendedFaviconRefresh();
          } catch (e) {
            // The watchdog alarm retries the persisted cursor.
            console.warn('[TabHibernate] initial favicon refresh step failed', e);
          }
        }
      } catch (e) {
        console.warn('[TabHibernate] refreshSuspendedFavicons failed', e);
        safeSend({ started: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }
  if (msg.type === 'removeSuspendedBookmark') {
    Promise.all([
      removeSuspendedBookmark(msg.url),
      removeSuspendedUrlIndex(msg.url),
    ]).then(() => safeSend({ ok: true })).catch(() => safeSend({ ok: false }));
    return true;
  }
  if (msg.type === 'suspendCurrentTab') {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) return safeSend({ ok: false, reason: 'No active tab' });
        const settings = await getSettings();
        if (!(await isTabEligibleForSuspend(tab, { allowActive: true, settings }))) {
          let reason = 'Cannot suspend this tab';
          if (tab.pinned && !settings.suspendPinnedTabs) reason = 'Tab is pinned (enable «Include pinned tabs» in Tab Hibernate)';
          else if (settings.skipGroupedInHibernate && isTabInGroup(tab)) reason = 'Tab is in a group (disable «Skip tabs in tab groups»)';
          else if (tab.url?.startsWith('chrome://') || tab.url?.startsWith('chrome-extension://')) reason = 'System page cannot be suspended';
          return safeSend({ ok: false, reason });
        }
        if (isTabExcludedByDomain(tab, settings.excludedDomains)) {
          return safeSend({ ok: false, reason: 'This domain is excluded in settings' });
        }
        const mode = getSuspendModeForTab(settings, tab);
        if (mode === 'placeholder' && !hasRestorableUrl(tab.url)) {
          return safeSend({ ok: false, reason: 'Cannot suspend: page has no restorable URL' });
        }
        const ok = mode === 'discard'
          ? await suspendDiscard(tab.id)
          : await suspendPlaceholder(tab.id, tab.url, tab.title, tab.favIconUrl, {
            groupId: tab.groupId,
            windowId: tab.windowId,
          });
        safeSend({ ok });
      } catch (e) {
        console.warn('[TabHibernate] suspendCurrentTab failed', e);
        safeSend({ ok: false, reason: String(e.message) });
      }
    })();
    return true;
  }
  if (msg.type === 'suspendAllNow') {
    runSuspendAllNow().then((res) => safeSend(res)).catch((e) => {
      console.warn('[TabHibernate] suspendAllNow failed', e);
      safeSend({ suspended: 0, error: String(e.message) });
    });
    return true;
  }
  if (msg.type === 'openUrlsAsPlaceholders') {
    runOpenUrlsAsPlaceholders(msg.items || [], {
      removeFromHistory: msg.removeFromHistory === true,
      windowId: sender.tab?.windowId,
    }).then((res) => safeSend(res)).catch((e) => {
      console.warn('[TabHibernate] openUrlsAsPlaceholders failed', e);
      safeSend({ opened: 0, error: String(e?.message || e) });
    });
    return true;
  }
  if (msg.type === 'removeUrlsFromHistory') {
    removeOpenedItemsFromHistory(msg.items || []).then(async (removed) => {
      await updateBadge();
      safeSend({ removed });
    }).catch((e) => {
      console.warn('[TabHibernate] removeUrlsFromHistory failed', e);
      safeSend({ removed: 0, error: String(e?.message || e) });
    });
    return true;
  }
  if (msg.type === 'recoverLostSuspended') {
    runRecoverLostSuspended().then((res) => safeSend(res)).catch((e) => {
      console.warn('[TabHibernate] recoverLostSuspended failed', e);
      safeSend({ recovered: 0, error: String(e.message) });
    });
    return true;
  }
  if (msg.type === 'searchLostTabsFromHistory') {
    searchLostTabsFromHistory({
      hoursBack: msg.hoursBack,
      onlyMissing: msg.onlyMissing !== false,
      maxResults: msg.maxResults,
      text: msg.text,
    }).then((res) => safeSend(res)).catch((e) => {
      console.warn('[TabHibernate] searchLostTabsFromHistory failed', e);
      safeSend({ items: [], error: String(e?.message || e) });
    });
    return true;
  }
  if (msg.type === 'recoverFromBrowserHistory') {
    runRecoverFromBrowserHistory({
      hoursBack: msg.hoursBack,
      onlyMissing: msg.onlyMissing !== false,
      maxResults: msg.maxResults,
      text: msg.text,
    }).then((res) => safeSend(res)).catch((e) => {
      console.warn('[TabHibernate] recoverFromBrowserHistory failed', e);
      safeSend({ recovered: 0, error: String(e?.message || e) });
    });
    return true;
  }
  if (msg.type === 'emergencyBackupNow') {
    runEmergencySessionBackup('manual').then((res) => safeSend(res)).catch((e) => {
      console.warn('[TabHibernate] emergencyBackupNow failed', e);
      safeSend({ count: 0, error: String(e?.message || e) });
    });
    return true;
  }
  if (msg.type === 'saveBlockedTabsNow') {
    (async () => {
      const { blocked = [], whitelist = [] } = await chrome.storage.local.get(['blocked', 'whitelist']);
      const wl = new Set((whitelist || []).map(sbNormDomain).filter(Boolean));
      const domains = (blocked || []).map(sbNormDomain).filter(Boolean).filter((d) => !wl.has(d));
      const res = await saveOpenTabsMatchingBlockedDomains(domains, 'manual');
      safeSend(res);
    })().catch((e) => {
      console.warn('[SiteBlocker] saveBlockedTabsNow failed', e);
      safeSend({ added: 0, error: String(e?.message || e) });
    });
    return true;
  }
  if (msg.type === 'restoreAllSuspended') {
    runRestoreAllSuspended().then((res) => safeSend(res)).catch((e) => {
      console.warn('[TabHibernate] restoreAllSuspended failed', e);
      safeSend({ restored: 0, error: String(e.message) });
    });
    return true;
  }
  if (msg.type === 'discardBackgroundTabs') {
    runDiscardBackgroundTabs().then((res) => safeSend(res)).catch((e) => {
      console.warn('[Memory] discard failed', e);
      safeSend({ discarded: 0, error: String(e.message) });
    });
    return true;
  }
  if (msg.type === 'closeAndSaveAll') {
    runCloseAndSaveAll().then(async (res) => {
      await chrome.storage.local.remove('closeAndSaveProgress');
      await updateBadge();
      safeSend(res);
    }).catch((e) => {
      console.warn('[TabHibernate] closeAndSaveAll failed', e);
      chrome.storage.local.remove('closeAndSaveProgress').catch(() => {});
      safeSend({ closed: 0, error: String(e.message) });
    });
    return true;
  }
  if (msg.type === 'closeAndSaveAllAsync') {
    startCloseAndSaveAllJob().then((res) => safeSend(res)).catch((e) => {
      console.warn('[TabHibernate] closeAndSaveAllAsync start failed', e);
      safeSend({ started: false, reason: String(e?.message || e) });
    });
    return true;
  }
  if (msg.type === 'saveTabGroup') {
    runSaveTabGroup({ closeTabs: false }).then((res) => safeSend(res)).catch((e) => {
      console.warn('[TabHibernate] saveTabGroup failed', e);
      safeSend({ saved: 0, error: String(e?.message || e) });
    });
    return true;
  }
  if (msg.type === 'closeTabGroupAndSave') {
    runSaveTabGroup({ closeTabs: true }).then((res) => safeSend(res)).catch((e) => {
      console.warn('[TabHibernate] closeTabGroupAndSave failed', e);
      safeSend({ saved: 0, closed: 0, error: String(e?.message || e) });
    });
    return true;
  }
  if (msg.type === 'prepareTabsForGrouping') {
    (async () => {
      for (const item of msg.items || []) {
        if (!item?.tabId || !item?.url) continue;
        await suspendPlaceholder(item.tabId, item.url, item.title || item.url, '', {
          windowId: item.windowId,
          skipFavicon: true,
          skipBookmark: true,
        });
      }
      safeSend({ ok: true });
    })().catch((e) => {
      console.warn('[TabHibernate] prepareTabsForGrouping failed', e);
      safeSend({ ok: false, error: String(e?.message || e) });
    });
    return true;
  }
  if (msg.type === 'syncPlaceholderGroupMeta') {
    syncSuspendedStorageGroupMetaForTabIds(msg.tabIds || [])
      .then(() => safeSend({ ok: true }))
      .catch((e) => safeSend({ ok: false, error: String(e?.message || e) }));
    return true;
  }
  if (msg.type === 'groupTabsByDomain') {
    runGroupTabsByDomain({
      allWindows: msg.allWindows === true,
      windowId: typeof msg.windowId === 'number' ? msg.windowId : null,
    }).then((res) => safeSend(res)).catch((e) => {
      console.warn('[TabHibernate] groupTabsByDomain failed', e);
      safeSend({ groupsCreated: 0, tabsGrouped: 0, error: String(e?.message || e) });
    });
    return true;
  }
  // Page Capture (Swiss Extensions)
  if (msg.type === 'getTiles') {
    const req = indexedDB.open('PdfCaptureDB', 1);
    req.onsuccess = () => {
      const db = req.result;
      const tx = db.transaction('capture', 'readwrite');
      const store = tx.objectStore('capture');
      const getReq = store.get('pending');
      getReq.onsuccess = () => {
        const data = getReq.result || {};
        store.delete('pending');
        tx.oncomplete = () => db.close();
        safeSend({ tiles: data.tiles || [], pageInfo: data.pageInfo || null, error: data.error || null });
      };
      getReq.onerror = () => { db.close(); safeSend({ tiles: [], pageInfo: null, error: 'Read error' }); };
    };
    req.onerror = () => safeSend({ tiles: [], pageInfo: null, error: 'IndexedDB unavailable' });
    req.onupgradeneeded = (e) => e.target.result.createObjectStore('capture');
    return true;
  }
  if (msg.type === 'capture') {
    if (captureInProgress) {
      safeSend({ error: 'A page capture is already in progress.' });
      return true;
    }
    captureInProgress = true;
    (async () => {
      let ownsCaptureState = false;
      try {
        const storedState = await chrome.storage.session.get(CAPTURE_STATE_KEY);
        const activeState = storedState[CAPTURE_STATE_KEY];
        const activeSince = Number(activeState?.startedAt || 0);
        if (activeState?.status === 'capturing'
          && Date.now() - activeSince >= 0
          && Date.now() - activeSince < CAPTURE_STATE_STALE_MS) {
          safeSend({ error: 'A page capture is already in progress.' });
          return;
        }
        await chrome.storage.session.set({
          [CAPTURE_STATE_KEY]: { status: 'capturing', startedAt: Date.now() },
        });
        ownsCaptureState = true;

        const SCROLL_DELAY_MS = 1500, FIRST_FRAME_DELAY_MS = 500;
        const cap = {
          getActiveTab: async () => { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); if (!t?.id) throw new Error('No active tab'); return t; },
          inject: (tid) => chrome.scripting.executeScript({ target: { tabId: tid }, files: ['content.js'] }),
          getPageHeight: async (tid) => (await chrome.tabs.sendMessage(tid, { type: 'getPageHeight' })).height,
          getViewportHeight: async (tid) => (await chrome.tabs.sendMessage(tid, { type: 'getViewportHeight' })).height,
          getScrollPosition: async (tid) => (await chrome.tabs.sendMessage(tid, { type: 'getScrollPosition' })).y,
          scrollTo: (tid, y) => chrome.tabs.sendMessage(tid, { type: 'scrollTo', y }),
          hideFloating: (tid) => chrome.tabs.sendMessage(tid, { type: 'hideFloating' }),
          showFloating: async (tid) => {
            try { await chrome.tabs.sendMessage(tid, { type: 'showFloating' }); } catch (_) {}
          },
        };
        const saveToIDB = (data) => new Promise((res, rej) => {
          const r = indexedDB.open('PdfCaptureDB', 1);
          r.onerror = () => rej(r.error);
          r.onsuccess = () => {
            const db = r.result;
            const tx = db.transaction('capture', 'readwrite');
            const store = tx.objectStore('capture');
            store.put(data, 'pending');
            tx.oncomplete = () => { db.close(); res(); };
            tx.onerror = () => { db.close(); rej(tx.error); };
          };
          r.onupgradeneeded = (e) => e.target.result.createObjectStore('capture');
        });
        let tabId = null;
        let originalScrollY = 0;
        try {
          const tab = await cap.getActiveTab();
          tabId = tab.id;
          if (!tab.url) {
            await saveToIDB({ error: 'No open page.' });
            chrome.tabs.create({ url: chrome.runtime.getURL('ui-dist/result.html'), index: tab.index + 1, windowId: tab.windowId });
            safeSend({ error: 'No open page.' }); return;
          }
          await cap.inject(tabId);
          await new Promise(r => setTimeout(r, 200));
          originalScrollY = await cap.getScrollPosition(tabId);
          await cap.hideFloating(tabId);
          await new Promise(r => setTimeout(r, 300));
          await cap.scrollTo(tabId, 0);
          await new Promise(r => setTimeout(r, 400));
          const [pageH, viewH] = await Promise.all([cap.getPageHeight(tabId), cap.getViewportHeight(tabId)]);
          const plan = SwissCore.getCapturePlan({
            pageHeight: pageH,
            viewportHeight: viewH,
            viewportWidth: tab.width || 1920,
          });
          if (!plan.ok) throw new Error(plan.error);
          const { step, totalFrames } = plan;
          const setProgress = (current) => {
            chrome.storage.local.set({ captureProgress: { total: totalFrames, current } });
          };
          setProgress(0);
          const tiles = [];
          let y = 0, first = true;
          while (tiles.length < totalFrames) {
            await cap.scrollTo(tabId, y);
            await new Promise(r => setTimeout(r, first ? FIRST_FRAME_DELAY_MS + SCROLL_DELAY_MS : SCROLL_DELAY_MS));
            tiles.push(await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' }));
            setProgress(tiles.length);
            y += step; first = false;
          }
          await saveToIDB({ tiles, pageInfo: { url: tab.url, title: tab.title || '' } });
          chrome.tabs.create({ url: chrome.runtime.getURL('ui-dist/result.html'), index: tab.index + 1, windowId: tab.windowId });
          safeSend({ ok: true, count: tiles.length });
        } catch (e) {
          const errText = formatSwissCaptureError(e);
          await saveToIDB({ error: errText });
          let t = null; if (tabId) try { t = await chrome.tabs.get(tabId); } catch (_) {}
          chrome.tabs.create({ url: chrome.runtime.getURL('ui-dist/result.html'), windowId: t?.windowId });
          safeSend({ error: errText });
        } finally {
          await chrome.storage.local.remove('captureProgress').catch(() => {});
          if (tabId) {
            try { await cap.scrollTo(tabId, originalScrollY); } catch (_) {}
            await cap.showFloating(tabId);
          }
        }
      } catch (e) {
        console.warn('[PageCapture] unexpected capture failure', e);
        safeSend({ error: formatSwissCaptureError(e) });
      } finally {
        if (ownsCaptureState) await chrome.storage.session.remove(CAPTURE_STATE_KEY).catch(() => {});
        captureInProgress = false;
      }
    })();
    return true;
  }
  return false;
});

chrome.commands?.onCommand.addListener((command) => {
  if (command === 'discard-background-tabs') {
    runDiscardBackgroundTabs().catch((e) => console.warn('[Memory]', e));
    return;
  }
  if (command !== 'suspend-current-tab') return;
  chrome.tabs.query({ active: true, currentWindow: true }).then(async ([tab]) => {
    if (!tab || !tab.id) return;
    const settings = await getSettings();
    if (!(await isTabEligibleForSuspend(tab, { allowActive: true, settings }))) return;
    if (isTabExcludedByDomain(tab, settings.excludedDomains)) return;
    const mode = getSuspendModeForTab(settings, tab);
    if (mode === 'placeholder' && !hasRestorableUrl(tab.url)) return;
    if (mode === 'discard') await suspendDiscard(tab.id);
    else await suspendPlaceholder(tab.id, tab.url, tab.title, tab.favIconUrl, {
      groupId: tab.groupId,
      windowId: tab.windowId,
    });
  }).catch((e) => {
    console.warn('[TabHibernate] command suspend-current-tab failed', e);
  });
});

// SW wake: alarms + restore activity only. Migrate/rebind runs in onStartup/onInstalled.
(async () => {
  try {
    await ensureServiceWorkerReady();
    await ensureRuntimePlaceholderRepair();
  } catch (e) {
    console.warn('[SwissExtensions] SW init failed', e);
  }
})();
